"""
نظام إدارة الحضور والرواتب - تطبيق الويب الخلفي
Factory Payroll Management System - Backend Application
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from functools import wraps
import os
import json
from datetime import datetime, timedelta
from database import DatabaseManager
import hashlib
import jwt
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import io

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'factory_payroll_secret_key_2024'

# تهيئة قاعدة البيانات
db = DatabaseManager()

# ============ التحقق من المصادقة ============

def token_required(f):
    """ديكوريتر للتحقق من التوكن"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'لم يتم تقديم توكن'}), 401
        
        try:
            token = token.replace('Bearer ', '')
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.user_id = data['user_id']
            request.user_role = data['role']
        except:
            return jsonify({'message': 'توكن غير صالح'}), 401
        
        return f(*args, **kwargs)
    return decorated

def role_required(roles):
    """ديكوريتر للتحقق من الصلاحيات"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if request.user_role not in roles:
                return jsonify({'message': 'ليس لديك صلاحيات كافية'}), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ============ نقاط النهاية - المصادقة ============

@app.route('/api/auth/login', methods=['POST'])
def login():
    """تسجيل الدخول"""
    data = request.json
    username = data.get('username')
    password = data.get('password')

    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, full_name, role FROM users WHERE username = ? AND password = ?', 
                   (username, password))
    user = cursor.fetchone()
    conn.close()

    if not user:
        return jsonify({'message': 'اسم مستخدم أو كلمة مرور خاطئة'}), 401

    token = jwt.encode({
        'user_id': user['id'],
        'role': user['role'],
        'exp': datetime.utcnow() + timedelta(hours=24)
    }, app.config['SECRET_KEY'], algorithm='HS256')

    db.log_activity(user['id'], 'تسجيل الدخول', 'User', user['id'])

    return jsonify({
        'token': token,
        'user_id': user['id'],
        'full_name': user['full_name'],
        'role': user['role']
    })

# ============ نقاط النهاية - الموظفين ============

@app.route('/api/employees', methods=['GET'])
@token_required
def get_employees():
    """الحصول على قائمة الموظفين"""
    conn = db.get_connection()
    cursor = conn.cursor()
    
    search = request.args.get('search', '')
    department_id = request.args.get('department_id')
    
    query = '''
        SELECT e.*, d.name as department_name, q.name as qualification_name
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN qualifications q ON e.qualification_id = q.id
        WHERE 1=1
    '''
    params = []
    
    if search:
        query += ' AND (e.full_name LIKE ? OR e.employee_id LIKE ? OR e.national_id LIKE ?)'
        search_param = f'%{search}%'
        params.extend([search_param, search_param, search_param])
    
    if department_id:
        query += ' AND e.department_id = ?'
        params.append(department_id)
    
    query += ' ORDER BY e.created_at DESC'
    
    cursor.execute(query, params)
    employees = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(employees)

@app.route('/api/employees/<int:employee_id>', methods=['GET'])
@token_required
def get_employee(employee_id):
    """الحصول على بيانات موظف محدد"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT e.*, d.name as department_name, q.name as qualification_name, q.daily_wage, q.overtime_rate
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN qualifications q ON e.qualification_id = q.id
        WHERE e.id = ?
    ''', (employee_id,))
    employee = dict(cursor.fetchone())
    conn.close()
    return jsonify(employee)

@app.route('/api/employees', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_employee():
    """إضافة موظف جديد"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO employees (
                employee_id, full_name, national_id, mobile_number,
                department_id, qualification_id, job_title, hiring_date, status, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('employee_id'),
            data.get('full_name'),
            data.get('national_id'),
            data.get('mobile_number'),
            data.get('department_id'),
            data.get('qualification_id'),
            data.get('job_title'),
            data.get('hiring_date'),
            data.get('status', 'نشط'),
            data.get('notes')
        ))
        
        conn.commit()
        employee_id = cursor.lastrowid
        db.log_activity(request.user_id, 'إضافة موظف', 'Employee', employee_id, f"تم إضافة {data.get('full_name')}")
        
        return jsonify({'message': 'تم إضافة الموظف بنجاح', 'id': employee_id}), 201
    except sqlite3.IntegrityError as e:
        return jsonify({'message': 'خطأ: هذا المعرف أو الرقم القومي موجود بالفعل'}), 400
    finally:
        conn.close()

@app.route('/api/employees/<int:employee_id>', methods=['PUT'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def update_employee(employee_id):
    """تحديث بيانات موظف"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE employees SET
            full_name = ?, national_id = ?, mobile_number = ?,
            department_id = ?, qualification_id = ?, job_title = ?,
            hiring_date = ?, status = ?, notes = ?, updated_at = ?
        WHERE id = ?
    ''', (
        data.get('full_name'),
        data.get('national_id'),
        data.get('mobile_number'),
        data.get('department_id'),
        data.get('qualification_id'),
        data.get('job_title'),
        data.get('hiring_date'),
        data.get('status'),
        data.get('notes'),
        datetime.now().isoformat(),
        employee_id
    ))
    
    conn.commit()
    conn.close()
    
    db.log_activity(request.user_id, 'تحديث موظف', 'Employee', employee_id)
    return jsonify({'message': 'تم تحديث الموظف بنجاح'})

@app.route('/api/employees/<int:employee_id>', methods=['DELETE'])
@token_required
@role_required(['Super Admin'])
def delete_employee(employee_id):
    """حذف موظف"""
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('DELETE FROM employees WHERE id = ?', (employee_id,))
    conn.commit()
    conn.close()
    
    db.log_activity(request.user_id, 'حذف موظف', 'Employee', employee_id)
    return jsonify({'message': 'تم حذف الموظف بنجاح'})

import sqlite3

# ============ نقاط النهاية - المؤهلات ============

@app.route('/api/qualifications', methods=['GET'])
@token_required
def get_qualifications():
    """الحصول على المؤهلات"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM qualifications ORDER BY id DESC')
    qualifications = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(qualifications)

@app.route('/api/qualifications', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_qualification():
    """إضافة مؤهل جديد"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO qualifications (name, daily_wage, overtime_rate, description)
            VALUES (?, ?, ?, ?)
        ''', (
            data.get('name'),
            data.get('daily_wage'),
            data.get('overtime_rate'),
            data.get('description')
        ))
        conn.commit()
        qual_id = cursor.lastrowid
        db.log_activity(request.user_id, 'إضافة مؤهل', 'Qualification', qual_id)
        return jsonify({'message': 'تم إضافة المؤهل بنجاح', 'id': qual_id}), 201
    finally:
        conn.close()

@app.route('/api/qualifications/<int:qual_id>', methods=['PUT'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def update_qualification(qual_id):
    """تحديث مؤهل"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE qualifications SET name = ?, daily_wage = ?, overtime_rate = ?, description = ?
        WHERE id = ?
    ''', (
        data.get('name'),
        data.get('daily_wage'),
        data.get('overtime_rate'),
        data.get('description'),
        qual_id
    ))
    
    conn.commit()
    conn.close()
    db.log_activity(request.user_id, 'تحديث مؤهل', 'Qualification', qual_id)
    return jsonify({'message': 'تم تحديث المؤهل بنجاح'})

@app.route('/api/qualifications/<int:qual_id>', methods=['DELETE'])
@token_required
@role_required(['Super Admin'])
def delete_qualification(qual_id):
    """حذف مؤهل"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM qualifications WHERE id = ?', (qual_id,))
    conn.commit()
    conn.close()
    db.log_activity(request.user_id, 'حذف مؤهل', 'Qualification', qual_id)
    return jsonify({'message': 'تم حذف المؤهل بنجاح'})

# ============ نقاط النهاية - الأقسام ============

@app.route('/api/departments', methods=['GET'])
@token_required
def get_departments():
    """الحصول على الأقسام"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM departments ORDER BY id DESC')
    departments = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(departments)

@app.route('/api/departments', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_department():
    """إضافة قسم جديد"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO departments (name, manager_name, description)
        VALUES (?, ?, ?)
    ''', (
        data.get('name'),
        data.get('manager_name'),
        data.get('description')
    ))
    
    conn.commit()
    dept_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'إضافة قسم', 'Department', dept_id)
    return jsonify({'message': 'تم إضافة القسم بنجاح', 'id': dept_id}), 201

@app.route('/api/departments/<int:dept_id>', methods=['PUT'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def update_department(dept_id):
    """تحديث قسم"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE departments SET name = ?, manager_name = ?, description = ?
        WHERE id = ?
    ''', (
        data.get('name'),
        data.get('manager_name'),
        data.get('description'),
        dept_id
    ))
    
    conn.commit()
    conn.close()
    db.log_activity(request.user_id, 'تحديث قسم', 'Department', dept_id)
    return jsonify({'message': 'تم تحديث القسم بنجاح'})

@app.route('/api/departments/<int:dept_id>', methods=['DELETE'])
@token_required
@role_required(['Super Admin'])
def delete_department(dept_id):
    """حذف قسم"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM departments WHERE id = ?', (dept_id,))
    conn.commit()
    conn.close()
    db.log_activity(request.user_id, 'حذف قسم', 'Department', dept_id)
    return jsonify({'message': 'تم حذف القسم بنجاح'})

# ============ نقاط النهاية - الحضور ============

@app.route('/api/attendance', methods=['GET'])
@token_required
def get_attendance():
    """الحصول على السجلات الحضورية"""
    date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    employee_id = request.args.get('employee_id')
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    query = 'SELECT a.*, e.full_name, e.employee_id FROM attendance a JOIN employees e ON a.employee_id = e.id WHERE 1=1'
    params = []
    
    if date:
        query += ' AND a.attendance_date = ?'
        params.append(date)
    
    if employee_id:
        query += ' AND a.employee_id = ?'
        params.append(employee_id)
    
    query += ' ORDER BY a.created_at DESC'
    
    cursor.execute(query, params)
    attendance = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(attendance)

@app.route('/api/attendance', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def record_attendance():
    """تسجيل الحضور"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT OR REPLACE INTO attendance (employee_id, attendance_date, status, notes, recorded_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            data.get('employee_id'),
            data.get('attendance_date'),
            data.get('status'),
            data.get('notes'),
            request.user_id
        ))
        
        conn.commit()
        att_id = cursor.lastrowid
        db.log_activity(request.user_id, 'تسجيل حضور', 'Attendance', att_id)
        return jsonify({'message': 'تم تسجيل الحضور بنجاح', 'id': att_id}), 201
    finally:
        conn.close()

# ============ نقاط النهاية - الإضافي ============

@app.route('/api/overtime', methods=['GET'])
@token_required
def get_overtime():
    """الحصول على سجلات الإضافي"""
    month = request.args.get('month', datetime.now().strftime('%Y-%m'))
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    query = '''
        SELECT o.*, e.full_name, e.employee_id, q.overtime_rate
        FROM overtime o
        JOIN employees e ON o.employee_id = e.id
        LEFT JOIN qualifications q ON e.qualification_id = q.id
        WHERE strftime('%Y-%m', o.overtime_date) = ?
        ORDER BY o.created_at DESC
    '''
    
    cursor.execute(query, (month,))
    overtime = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(overtime)

@app.route('/api/overtime', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_overtime():
    """إضافة ساعات إضافية"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO overtime (employee_id, overtime_date, hours, notes, recorded_by)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data.get('employee_id'),
        data.get('overtime_date'),
        data.get('hours'),
        data.get('notes'),
        request.user_id
    ))
    
    conn.commit()
    ot_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'إضافة إضافي', 'Overtime', ot_id)
    return jsonify({'message': 'تم إضافة الإضافي بنجاح', 'id': ot_id}), 201

# ============ نقاط النهاية - السلفات ============

@app.route('/api/advances', methods=['GET'])
@token_required
def get_advances():
    """الحصول على السلفات"""
    employee_id = request.args.get('employee_id')
    status = request.args.get('status')
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    query = 'SELECT a.*, e.full_name FROM advances a JOIN employees e ON a.employee_id = e.id WHERE 1=1'
    params = []
    
    if employee_id:
        query += ' AND a.employee_id = ?'
        params.append(employee_id)
    
    if status:
        query += ' AND a.status = ?'
        params.append(status)
    
    query += ' ORDER BY a.created_at DESC'
    
    cursor.execute(query, params)
    advances = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(advances)

@app.route('/api/advances', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_advance():
    """إضافة سلفة"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO advances (employee_id, amount, advance_date, reason, status, recorded_by, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get('employee_id'),
        data.get('amount'),
        data.get('advance_date'),
        data.get('reason'),
        data.get('status', 'معلقة'),
        request.user_id,
        data.get('notes')
    ))
    
    conn.commit()
    adv_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'إضافة سلفة', 'Advance', adv_id)
    return jsonify({'message': 'تم إضافة السلفة بنجاح', 'id': adv_id}), 201

# ============ نقاط النهاية - الخصومات ============

@app.route('/api/deductions', methods=['GET'])
@token_required
def get_deductions():
    """الحصول على الخصومات"""
    employee_id = request.args.get('employee_id')
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    query = 'SELECT d.*, e.full_name FROM deductions d JOIN employees e ON d.employee_id = e.id WHERE 1=1'
    params = []
    
    if employee_id:
        query += ' AND d.employee_id = ?'
        params.append(employee_id)
    
    query += ' ORDER BY d.created_at DESC'
    
    cursor.execute(query, params)
    deductions = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(deductions)

@app.route('/api/deductions', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_deduction():
    """إضافة خصم"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO deductions (employee_id, amount, deduction_date, reason, recorded_by, notes)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (
        data.get('employee_id'),
        data.get('amount'),
        data.get('deduction_date'),
        data.get('reason'),
        request.user_id,
        data.get('notes')
    ))
    
    conn.commit()
    ded_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'إضافة خصم', 'Deduction', ded_id)
    return jsonify({'message': 'تم إضافة الخصم بنجاح', 'id': ded_id}), 201

# ============ نقاط النهاية - المكافآت ============

@app.route('/api/bonuses', methods=['GET'])
@token_required
def get_bonuses():
    """الحصول على المكافآت"""
    employee_id = request.args.get('employee_id')
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    query = 'SELECT b.*, e.full_name FROM bonuses b JOIN employees e ON b.employee_id = e.id WHERE 1=1'
    params = []
    
    if employee_id:
        query += ' AND b.employee_id = ?'
        params.append(employee_id)
    
    query += ' ORDER BY b.created_at DESC'
    
    cursor.execute(query, params)
    bonuses = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(bonuses)

@app.route('/api/bonuses', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def add_bonus():
    """إضافة مكافأة"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO bonuses (employee_id, amount, bonus_date, reason, bonus_type, recorded_by, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get('employee_id'),
        data.get('amount'),
        data.get('bonus_date'),
        data.get('reason'),
        data.get('bonus_type'),
        request.user_id,
        data.get('notes')
    ))
    
    conn.commit()
    bonus_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'إضافة مكافأة', 'Bonus', bonus_id)
    return jsonify({'message': 'تم إضافة المكافأة بنجاح', 'id': bonus_id}), 201

# ============ نقاط النهاية - كشوف الرواتب ============

@app.route('/api/payroll/calculate', methods=['POST'])
@token_required
@role_required(['Super Admin', 'HR Officer'])
def calculate_payroll():
    """حساب كشف الرواتب"""
    data = request.json
    employee_id = data.get('employee_id')
    period = data.get('period')  # YYYY-MM-DD to YYYY-MM-DD
    period_type = data.get('period_type')  # أسبوعي or شهري
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    # الحصول على بيانات الموظف
    cursor.execute('''
        SELECT e.*, q.daily_wage, q.overtime_rate
        FROM employees e
        LEFT JOIN qualifications q ON e.qualification_id = q.id
        WHERE e.id = ?
    ''', (employee_id,))
    employee = cursor.fetchone()
    
    start_date, end_date = period.split(' to ')
    
    # حساب أيام الحضور
    cursor.execute('''
        SELECT COUNT(*) as count FROM attendance
        WHERE employee_id = ? AND attendance_date BETWEEN ? AND ? AND status = 'حاضر'
    ''', (employee_id, start_date, end_date))
    attendance_days = cursor.fetchone()[0]
    
    # حساب أيام الغياب
    cursor.execute('''
        SELECT COUNT(*) as count FROM attendance
        WHERE employee_id = ? AND attendance_date BETWEEN ? AND ? AND status = 'غائب'
    ''', (employee_id, start_date, end_date))
    absent_days = cursor.fetchone()[0]
    
    # حساب ساعات الإضافي
    cursor.execute('''
        SELECT COALESCE(SUM(hours), 0) as total FROM overtime
        WHERE employee_id = ? AND overtime_date BETWEEN ? AND ?
    ''', (employee_id, start_date, end_date))
    overtime_hours = cursor.fetchone()[0]
    
    # حساب السلفات
    cursor.execute('''
        SELECT COALESCE(SUM(amount), 0) as total FROM advances
        WHERE employee_id = ? AND advance_date BETWEEN ? AND ? AND status = 'موافق عليها'
    ''', (employee_id, start_date, end_date))
    advances_total = cursor.fetchone()[0]
    
    # حساب الخصومات
    cursor.execute('''
        SELECT COALESCE(SUM(amount), 0) as total FROM deductions
        WHERE employee_id = ? AND deduction_date BETWEEN ? AND ?
    ''', (employee_id, start_date, end_date))
    deductions_total = cursor.fetchone()[0]
    
    # حساب المكافآت
    cursor.execute('''
        SELECT COALESCE(SUM(amount), 0) as total FROM bonuses
        WHERE employee_id = ? AND bonus_date BETWEEN ? AND ?
    ''', (employee_id, start_date, end_date))
    bonuses_total = cursor.fetchone()[0]
    
    # الحسابات
    daily_wage = employee['daily_wage'] or 0
    overtime_rate = employee['overtime_rate'] or 0
    
    attendance_salary = attendance_days * daily_wage
    overtime_salary = overtime_hours * overtime_rate
    net_salary = attendance_salary + overtime_salary + bonuses_total - advances_total - deductions_total
    
    period_str = f"{start_date} to {end_date}"
    
    # حفظ كشف الراتب
    cursor.execute('''
        INSERT INTO payroll (
            employee_id, payroll_period, period_type, attendance_days, absent_days,
            overtime_hours, attendance_salary, overtime_salary, bonuses_total,
            advances_total, deductions_total, net_salary, generated_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        employee_id, period_str, period_type, attendance_days, absent_days,
        overtime_hours, attendance_salary, overtime_salary, bonuses_total,
        advances_total, deductions_total, net_salary, request.user_id
    ))
    
    conn.commit()
    payroll_id = cursor.lastrowid
    conn.close()
    
    db.log_activity(request.user_id, 'حساب راتب', 'Payroll', payroll_id)
    
    return jsonify({
        'id': payroll_id,
        'employee_id': employee_id,
        'employee_name': employee['full_name'],
        'period': period_str,
        'attendance_days': attendance_days,
        'absent_days': absent_days,
        'overtime_hours': overtime_hours,
        'attendance_salary': attendance_salary,
        'overtime_salary': overtime_salary,
        'bonuses_total': bonuses_total,
        'advances_total': advances_total,
        'deductions_total': deductions_total,
        'net_salary': net_salary
    })

@app.route('/api/payroll', methods=['GET'])
@token_required
def get_payroll():
    """الحصول على كشوف الرواتب"""
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT p.*, e.full_name, e.employee_id
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        ORDER BY p.created_at DESC
    ''')
    payroll = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify(payroll)

# ============ نقاط النهاية - الإحصائيات والتقارير ============

@app.route('/api/dashboard', methods=['GET'])
@token_required
def get_dashboard():
    """الحصول على بيانات لوحة التحكم"""
    conn = db.get_connection()
    cursor = conn.cursor()
    
    today = datetime.now().strftime('%Y-%m-%d')
    current_month = datetime.now().strftime('%Y-%m')
    current_week_start = (datetime.now() - timedelta(days=datetime.now().weekday())).strftime('%Y-%m-%d')
    current_week_end = (datetime.now() + timedelta(days=6-datetime.now().weekday())).strftime('%Y-%m-%d')
    
    # إجمالي العاملين
    cursor.execute('SELECT COUNT(*) as total FROM employees WHERE status = "نشط"')
    total_workers = cursor.fetchone()[0]
    
    # الحاضرين اليوم
    cursor.execute('''
        SELECT COUNT(DISTINCT employee_id) as total FROM attendance
        WHERE attendance_date = ? AND status = 'حاضر'
    ''', (today,))
    present_today = cursor.fetchone()[0]
    
    # الغائبين اليوم
    cursor.execute('''
        SELECT COUNT(DISTINCT employee_id) as total FROM attendance
        WHERE attendance_date = ? AND status = 'غائب'
    ''', (today,))
    absent_today = cursor.fetchone()[0]
    
    # إجمالي رواتب الأسبوع
    cursor.execute('''
        SELECT COALESCE(SUM(net_salary), 0) as total FROM payroll
        WHERE payroll_period LIKE ? AND period_type = 'أسبوعي'
    ''', (f'%{current_week_start}%',))
    weekly_payroll = cursor.fetchone()[0]
    
    # إجمالي رواتب الشهر
    cursor.execute('''
        SELECT COALESCE(SUM(net_salary), 0) as total FROM payroll
        WHERE payroll_period LIKE ? AND period_type = 'شهري'
    ''', (f'{current_month}%',))
    monthly_payroll = cursor.fetchone()[0]
    
    # إجمالي ساعات الإضافي
    cursor.execute('''
        SELECT COALESCE(SUM(hours), 0) as total FROM overtime
        WHERE strftime('%Y-%m', overtime_date) = ?
    ''', (current_month,))
    total_overtime = cursor.fetchone()[0]
    
    # إجمالي السلفات
    cursor.execute('''
        SELECT COALESCE(SUM(amount), 0) as total FROM advances
        WHERE strftime('%Y-%m', advance_date) = ? AND status = 'موافق عليها'
    ''', (current_month,))
    total_advances = cursor.fetchone()[0]
    
    # إجمالي الخصومات
    cursor.execute('''
        SELECT COALESCE(SUM(amount), 0) as total FROM deductions
        WHERE strftime('%Y-%m', deduction_date) = ?
    ''', (current_month,))
    total_deductions = cursor.fetchone()[0]
    
    # آخر النشاطات
    cursor.execute('''
        SELECT al.*, u.full_name FROM activity_log al
        LEFT JOIN users u ON al.user_id = u.id
        ORDER BY al.created_at DESC
        LIMIT 10
    ''')
    recent_activities = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return jsonify({
        'total_workers': total_workers,
        'present_today': present_today,
        'absent_today': absent_today,
        'weekly_payroll': weekly_payroll,
        'monthly_payroll': monthly_payroll,
        'total_overtime': total_overtime,
        'total_advances': total_advances,
        'total_deductions': total_deductions,
        'recent_activities': recent_activities
    })

# ============ نقاط النهاية - الإعدادات ============

@app.route('/api/settings', methods=['GET'])
@token_required
def get_settings():
    """الحصول على الإعدادات"""
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM settings LIMIT 1')
    settings = dict(cursor.fetchone())
    conn.close()
    return jsonify(settings)

@app.route('/api/settings', methods=['PUT'])
@token_required
@role_required(['Super Admin'])
def update_settings():
    """تحديث الإعدادات"""
    data = request.json
    
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        UPDATE settings SET
            company_name = ?, factory_name = ?, currency = ?, currency_symbol = ?
        WHERE id = 1
    ''', (
        data.get('company_name'),
        data.get('factory_name'),
        data.get('currency'),
        data.get('currency_symbol')
    ))
    
    conn.commit()
    conn.close()
    
    db.log_activity(request.user_id, 'تحديث الإعدادات', 'Settings', 1)
    return jsonify({'message': 'تم تحديث الإعدادات بنجاح'})

# ============ نقاط النهاية - النسخ الاحتياطي ============

@app.route('/api/backup', methods=['POST'])
@token_required
@role_required(['Super Admin'])
def create_backup():
    """إنشاء نسخة احتياطية"""
    success, result = db.backup_database()
    if success:
        db.log_activity(request.user_id, 'نسخة احتياطية', 'Backup', 0, f'تم إنشاء نسخة احتياطية: {result}')
        return jsonify({'message': 'تم إنشاء النسخة الاحتياطية بنجاح', 'file': result})
    else:
        return jsonify({'message': f'خطأ: {result}'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
