"""
نظام إدارة الحضور والرواتب - قاعدة البيانات
Factory Payroll Management System - Database Module
"""

import sqlite3
import os
from datetime import datetime
import json

class DatabaseManager:
    def __init__(self, db_path='factory_payroll.db'):
        self.db_path = db_path
        self.init_database()

    def get_connection(self):
        """الحصول على اتصال قاعدة البيانات"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_database(self):
        """تهيئة قاعدة البيانات وإنشاء الجداول"""
        conn = self.get_connection()
        cursor = conn.cursor()

        # جدول الشركات والمصانع
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY,
                company_name TEXT,
                factory_name TEXT,
                logo_path TEXT,
                currency TEXT DEFAULT 'EGP',
                currency_symbol TEXT DEFAULT '﷼',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # جدول المستخدمين والإداريين
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT,
                email TEXT,
                role TEXT CHECK(role IN ('Super Admin', 'HR Officer', 'Read Only')),
                is_active BOOLEAN DEFAULT 1,
                last_login TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # جدول المؤهلات والتخصصات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS qualifications (
                id INTEGER PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                daily_wage REAL NOT NULL,
                overtime_rate REAL NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # جدول الأقسام
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS departments (
                id INTEGER PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                manager_name TEXT,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # جدول الموظفين
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY,
                employee_id TEXT UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                national_id TEXT UNIQUE,
                mobile_number TEXT,
                department_id INTEGER,
                qualification_id INTEGER,
                job_title TEXT,
                hiring_date TEXT,
                status TEXT CHECK(status IN ('نشط', 'غير نشط')) DEFAULT 'نشط',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (department_id) REFERENCES departments(id),
                FOREIGN KEY (qualification_id) REFERENCES qualifications(id)
            )
        ''')

        # جدول الحضور
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                attendance_date TEXT NOT NULL,
                status TEXT CHECK(status IN ('حاضر', 'غائب', 'نصف يوم', 'إجازة', 'إجازة مرضية')),
                notes TEXT,
                recorded_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id),
                UNIQUE(employee_id, attendance_date)
            )
        ''')

        # جدول الإضافي (Overtime)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS overtime (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                overtime_date TEXT NOT NULL,
                hours REAL NOT NULL,
                notes TEXT,
                recorded_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')

        # جدول السلفات (Advances)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS advances (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                advance_date TEXT NOT NULL,
                reason TEXT,
                status TEXT CHECK(status IN ('معلقة', 'موافق عليها', 'مرفوضة')) DEFAULT 'معلقة',
                deduction_status TEXT CHECK(deduction_status IN ('لم تخصم', 'مخصومة جزئياً', 'مخصومة بالكامل')) DEFAULT 'لم تخصم',
                recorded_by INTEGER,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')

        # جدول الخصومات (Deductions)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS deductions (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                deduction_date TEXT NOT NULL,
                reason TEXT NOT NULL,
                recorded_by INTEGER,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')

        # جدول المكافآت (Bonuses)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bonuses (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                bonus_date TEXT NOT NULL,
                reason TEXT NOT NULL,
                bonus_type TEXT,
                recorded_by INTEGER,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')

        # جدول كشوف الرواتب الشهرية
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payroll (
                id INTEGER PRIMARY KEY,
                employee_id INTEGER NOT NULL,
                payroll_period TEXT NOT NULL,
                period_type TEXT CHECK(period_type IN ('أسبوعي', 'شهري')),
                attendance_days INTEGER DEFAULT 0,
                absent_days INTEGER DEFAULT 0,
                overtime_hours REAL DEFAULT 0,
                attendance_salary REAL DEFAULT 0,
                overtime_salary REAL DEFAULT 0,
                bonuses_total REAL DEFAULT 0,
                advances_total REAL DEFAULT 0,
                deductions_total REAL DEFAULT 0,
                net_salary REAL DEFAULT 0,
                status TEXT CHECK(status IN ('مسودة', 'نهائي', 'مدفوع')) DEFAULT 'مسودة',
                payment_date TEXT,
                notes TEXT,
                generated_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id),
                FOREIGN KEY (generated_by) REFERENCES users(id)
            )
        ''')

        # جدول النشاطات السجلية (Activity Log)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY,
                user_id INTEGER,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id INTEGER,
                description TEXT,
                ip_address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')

        # إدراج بيانات افتراضية
        self._insert_default_data(cursor)

        conn.commit()
        conn.close()

    def _insert_default_data(self, cursor):
        """إدراج البيانات الافتراضية"""
        
        # التحقق من وجود مستخدم افتراضي
        cursor.execute('SELECT COUNT(*) FROM users')
        if cursor.fetchone()[0] == 0:
            # إدراج مستخدم المسؤول الأساسي
            cursor.execute('''
                INSERT INTO users (username, password, full_name, role, email)
                VALUES (?, ?, ?, ?, ?)
            ''', ('admin', 'admin123', 'الإدارة العليا', 'Super Admin', 'admin@factory.com'))

        # التحقق من وجود مؤهلات افتراضية
        cursor.execute('SELECT COUNT(*) FROM qualifications')
        if cursor.fetchone()[0] == 0:
            qualifications = [
                ('بدون مؤهل', 180, 12),
                ('تعليم ابتدائي', 200, 13),
                ('دبلوم', 250, 15),
                ('درجة جامعية', 300, 18),
            ]
            cursor.executemany('''
                INSERT INTO qualifications (name, daily_wage, overtime_rate)
                VALUES (?, ?, ?)
            ''', qualifications)

        # التحقق من وجود أقسام افتراضية
        cursor.execute('SELECT COUNT(*) FROM departments')
        if cursor.fetchone()[0] == 0:
            departments = [
                ('الإنتاج', 'م. الإنتاج', 'قسم الإنتاج الرئيسي'),
                ('الصيانة', 'م. الصيانة', 'قسم الصيانة والإصلاح'),
                ('الجودة', 'م. الجودة', 'قسم مراقبة الجودة'),
                ('الإدارة', 'م. الإدارة', 'القسم الإداري'),
            ]
            cursor.executemany('''
                INSERT INTO departments (name, manager_name, description)
                VALUES (?, ?, ?)
            ''', departments)

        # التحقق من وجود إعدادات افتراضية
        cursor.execute('SELECT COUNT(*) FROM settings')
        if cursor.fetchone()[0] == 0:
            cursor.execute('''
                INSERT INTO settings (company_name, factory_name, currency, currency_symbol)
                VALUES (?, ?, ?, ?)
            ''', ('الشركة العربية', 'مصنع إنتاج', 'EGP', '﷼'))

    def log_activity(self, user_id, action, entity_type=None, entity_id=None, description=None):
        """تسجيل النشاطات"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO activity_log (user_id, action, entity_type, entity_id, description)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, action, entity_type, entity_id, description))
        conn.commit()
        conn.close()

    def backup_database(self, backup_path=None):
        """عمل نسخة احتياطية من قاعدة البيانات"""
        import shutil
        if backup_path is None:
            backup_path = f'backup_factory_payroll_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
        try:
            shutil.copy(self.db_path, backup_path)
            return True, backup_path
        except Exception as e:
            return False, str(e)

    def restore_database(self, backup_path):
        """استعادة قاعدة البيانات من نسخة احتياطية"""
        import shutil
        try:
            shutil.copy(backup_path, self.db_path)
            return True
        except Exception as e:
            return False, str(e)

# إنشاء مثيل عام من مدير قاعدة البيانات
db = DatabaseManager()
