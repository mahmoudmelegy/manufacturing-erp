# نظام إدارة الحضور والرواتب - شرح قاعدة البيانات
# Factory Payroll Management System - Database Schema Documentation

## مقدمة عن قاعدة البيانات

قاعدة البيانات تستخدم SQLite وتحتوي على 14 جدول رئيسي:

---

## الجداول الرئيسية

### 1. جدول الإعدادات (settings)
**الغرض:** تخزين معلومات الشركة والمصنع والعملة

```sql
CREATE TABLE settings (
    id INTEGER PRIMARY KEY,
    company_name TEXT,
    factory_name TEXT,
    logo_path TEXT,
    currency TEXT DEFAULT 'EGP',
    currency_symbol TEXT DEFAULT '﷼',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

**الحقول:**
- `id`: معرف فريد
- `company_name`: اسم الشركة
- `factory_name`: اسم المصنع
- `logo_path`: مسار شعار الشركة
- `currency`: نوع العملة (EGP, USD, etc)
- `currency_symbol`: رمز العملة (﷼)

---

### 2. جدول المستخدمين (users)
**الغرض:** تخزين بيانات المستخدمين والمسؤولين

```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    email TEXT,
    role TEXT CHECK(role IN ('Super Admin', 'HR Officer', 'Read Only')),
    is_active BOOLEAN DEFAULT 1,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

**الحقول:**
- `id`: معرف المستخدم الفريد
- `username`: اسم المستخدم (يجب أن يكون فريداً)
- `password`: كلمة المرور
- `full_name`: الاسم الكامل
- `email`: البريد الإلكتروني
- `role`: نوع الصلاحيات (Super Admin / HR Officer / Read Only)
- `is_active`: هل المستخدم فعال
- `last_login`: آخر وقت تسجيل دخول

**الأدوار:**
- **Super Admin**: صلاحيات كاملة (إضافة/تعديل/حذف جميع البيانات)
- **HR Officer**: إدارة الموظفين والرواتب (بدون حذف)
- **Read Only**: عرض البيانات فقط

---

### 3. جدول المؤهلات (qualifications)
**الغرض:** تخزين المؤهلات ومعدلات الأجور

```sql
CREATE TABLE qualifications (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    daily_wage REAL NOT NULL,
    overtime_rate REAL NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

**الحقول:**
- `id`: معرف المؤهل الفريد
- `name`: اسم المؤهل (مثلاً: درجة جامعية)
- `daily_wage`: أجرة اليوم الواحد بالعملة المحددة
- `overtime_rate`: معدل الساعة الإضافية
- `description`: وصف المؤهل

**مثال على البيانات:**
```
ID | اسم المؤهل      | الأجرة اليومية | أجرة الإضافي
1  | بدون مؤهل       | 180 ﷼         | 12 ﷼/الساعة
2  | تعليم ابتدائي  | 200 ﷼         | 13 ﷼/الساعة
3  | دبلوم          | 250 ﷼         | 15 ﷼/الساعة
4  | درجة جامعية    | 300 ﷼         | 18 ﷼/الساعة
```

---

### 4. جدول الأقسام (departments)
**الغرض:** تخزين معلومات الأقسام الإدارية

```sql
CREATE TABLE departments (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    manager_name TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

**الحقول:**
- `id`: معرف القسم الفريد
- `name`: اسم القسم (مثلاً: الإنتاج)
- `manager_name`: اسم مدير القسم
- `description`: وصف القسم

---

### 5. جدول الموظفين (employees)
**الغرض:** تخزين بيانات الموظفين الشاملة

```sql
CREATE TABLE employees (
    id INTEGER PRIMARY KEY,
    employee_id TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    national_id TEXT UNIQUE,
    mobile_number TEXT,
    department_id INTEGER,
    qualification_id INTEGER,
    job_title TEXT,
    hiring_date TEXT,
    status TEXT CHECK(status IN ('نشط', 'غير نشط')) DEFAULT 'نشط',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id),
    FOREIGN KEY (qualification_id) REFERENCES qualifications(id)
)
```

**الحقول الرئيسية:**
- `id`: معرف الموظف الداخلي
- `employee_id`: معرف الموظف المخصص (مثلاً: E001)
- `full_name`: الاسم الكامل للموظف
- `national_id`: الرقم القومي أو رقم البطاقة
- `mobile_number`: رقم الهاتف
- `department_id`: معرف القسم (علاقة خارجية)
- `qualification_id`: معرف المؤهل (علاقة خارجية)
- `status`: حالة الموظف (نشط/غير نشط)

---

### 6. جدول الحضور والغياب (attendance)
**الغرض:** تسجيل الحضور والغياب اليومي

```sql
CREATE TABLE attendance (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    attendance_date TEXT NOT NULL,
    status TEXT CHECK(status IN ('حاضر', 'غائب', 'نصف يوم', 'إجازة', 'إجازة مرضية')),
    notes TEXT,
    recorded_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id),
    UNIQUE(employee_id, attendance_date)
)
```

**حالات الحضور المدعومة:**
- `حاضر`: الموظف حضر يوماً كاملاً
- `غائب`: الموظف غائب
- `نصف يوم`: الموظف عمل نصف يوم
- `إجازة`: إجازة مأجورة
- `إجازة مرضية`: إجازة مرضية

---

### 7. جدول الإضافي (overtime)
**الغرض:** تسجيل ساعات العمل الإضافي

```sql
CREATE TABLE overtime (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    overtime_date TEXT NOT NULL,
    hours REAL NOT NULL,
    notes TEXT,
    recorded_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
)
```

**الحساب التلقائي:**
```
مبلغ الإضافي = عدد الساعات × معدل الساعة الإضافية للمؤهل
مثال: 5 ساعات × 15 ﷼/الساعة = 75 ﷼
```

---

### 8. جدول السلفات (advances)
**الغرض:** إدارة السلفات المقدمة للموظفين

```sql
CREATE TABLE advances (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    advance_date TEXT NOT NULL,
    reason TEXT,
    status TEXT CHECK(status IN ('معلقة', 'موافق عليها', 'مرفوضة')) DEFAULT 'معلقة',
    deduction_status TEXT CHECK(deduction_status IN ('لم تخصم', 'مخصومة جزئياً', 'مخصومة بالكامل')) DEFAULT 'لم تخصم',
    recorded_by INTEGER,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
)
```

**الحالات:**
- `معلقة`: السلفة قيد الانتظار
- `موافق عليها`: تمت الموافقة على السلفة
- `مرفوضة`: تم رفض السلفة

---

### 9. جدول الخصومات (deductions)
**الغرض:** تسجيل الخصومات على الرواتب

```sql
CREATE TABLE deductions (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    deduction_date TEXT NOT NULL,
    reason TEXT NOT NULL,
    recorded_by INTEGER,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
)
```

**أسباب الخصم الشائعة:**
- الغياب بدون عذر
- التأخر المتكرر
- الأضرار المتسبب فيها
- خصومات قانونية

---

### 10. جدول المكافآت (bonuses)
**الغرض:** تسجيل المكافآت والحوافز

```sql
CREATE TABLE bonuses (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    bonus_date TEXT NOT NULL,
    reason TEXT NOT NULL,
    bonus_type TEXT,
    recorded_by INTEGER,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (recorded_by) REFERENCES users(id)
)
```

**أنواع المكافآت:**
- أداء متميز
- إنتاجية عالية
- مكافأة سنوية
- حافز موسمي

---

### 11. جدول كشوف الرواتب (payroll)
**الغرض:** تخزين كشوف الرواتب الشهرية/الأسبوعية

```sql
CREATE TABLE payroll (
    id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL,
    payroll_period TEXT NOT NULL,
    period_type TEXT CHECK(period_type IN ('أسبوعي', 'شهري')),
    attendance_days INTEGER DEFAULT 0,
    absent_days INTEGER DEFAULT 0,
    overtime_hours REAL DEFAULT 0,
    attendance_salary REAL DEFAULT 0,
    overtime_salary REAL DEFAULT 0,
    bonuses_total REAL DEFAULT 0,
    advances_total REAL DEFAULT 0,
    deductions_total REAL DEFAULT 0,
    net_salary REAL DEFAULT 0,
    status TEXT CHECK(status IN ('مسودة', 'نهائي', 'مدفوع')) DEFAULT 'مسودة',
    payment_date TEXT,
    notes TEXT,
    generated_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (generated_by) REFERENCES users(id)
)
```

**الحسابات:**
```
راتب الحضور = أيام الحضور × أجرة اليوم الواحد
راتب الإضافي = ساعات الإضافي × معدل الساعة
صافي الراتب = راتب الحضور + راتب الإضافي + المكافآت - السلفات - الخصومات
```

**الحالات:**
- `مسودة`: كشف الراتب في مرحلة التحرير
- `نهائي`: كشف الراتب نهائي ولم يتم الدفع
- `مدفوع`: تم دفع الراتب

---

### 12. جدول السجل النشاطي (activity_log)
**الغرض:** تسجيل جميع العمليات والتغييرات

```sql
CREATE TABLE activity_log (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id INTEGER,
    description TEXT,
    ip_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)
```

**أنواع العمليات المسجلة:**
- تسجيل دخول/خروج
- إضافة/تعديل/حذف موظف
- تسجيل حضور
- حساب راتب
- إنشاء نسخة احتياطية

---

## العلاقات بين الجداول

```
users (المستخدمون)
├─ employees (records attendance, overtime, etc)
├─ attendance (recorded_by)
├─ overtime (recorded_by)
├─ advances (recorded_by)
├─ deductions (recorded_by)
├─ bonuses (recorded_by)
├─ payroll (generated_by)
└─ activity_log (user_id)

employees (الموظفون)
├─ department_id → departments
├─ qualification_id → qualifications
├─ attendance
├─ overtime
├─ advances
├─ deductions
├─ bonuses
└─ payroll

qualifications (المؤهلات)
└─ employees (يستخدمون للحساب)

departments (الأقسام)
└─ employees
```

---

## استعلامات شائعة

### حساب رواتب موظف معين
```sql
SELECT 
    e.full_name,
    COUNT(CASE WHEN a.status = 'حاضر' THEN 1 END) as attendance_days,
    q.daily_wage,
    (COUNT(CASE WHEN a.status = 'حاضر' THEN 1 END) * q.daily_wage) as attendance_salary,
    SUM(o.hours) as overtime_hours,
    (SUM(o.hours) * q.overtime_rate) as overtime_salary,
    (SELECT COALESCE(SUM(amount), 0) FROM bonuses WHERE employee_id = e.id) as bonuses_total,
    (SELECT COALESCE(SUM(amount), 0) FROM advances WHERE employee_id = e.id) as advances_total,
    (SELECT COALESCE(SUM(amount), 0) FROM deductions WHERE employee_id = e.id) as deductions_total
FROM employees e
LEFT JOIN qualifications q ON e.qualification_id = q.id
LEFT JOIN attendance a ON e.id = a.employee_id AND MONTH(a.attendance_date) = MONTH(CURRENT_DATE)
LEFT JOIN overtime o ON e.id = o.employee_id AND MONTH(o.overtime_date) = MONTH(CURRENT_DATE)
WHERE e.id = ?
GROUP BY e.id
```

### إحصائيات يومية
```sql
SELECT 
    COUNT(DISTINCT employee_id) as total_employees,
    COUNT(CASE WHEN status = 'حاضر' THEN 1 END) as present_today,
    COUNT(CASE WHEN status = 'غائب' THEN 1 END) as absent_today
FROM attendance
WHERE attendance_date = CURRENT_DATE
```

---

## ملاحظات مهمة

1. **البيانات المخزنة محلياً**: جميع البيانات تُخزن على الجهاز المحلي فقط
2. **النسخ الاحتياطية**: يتم إنشاء نسخ احتياطية تلقائياً يومياً
3. **قابلية التوسع**: يمكن ترقية إلى MySQL بسهولة

---

## تصدير واستيراد البيانات

### تصدير إلى Excel
```python
# يتم تنفيذها من الواجهة الرسومية
# الملفات المُصدَّرة تتضمن:
# - كشوف الرواتب
# - تقارير الحضور
# - تقارير الإضافي
```

### تصدير إلى PDF
```python
# يتم توليد PDF بصيغة احترافية
# تتضمن التوقيع والختوم
```

---

التاريخ الأخير للتحديث: يناير 2024
