"""
نظام إدارة الحضور والرواتب - وحدات المساعدة
Factory Payroll Management System - Utility Functions
"""

from datetime import datetime, timedelta
from database import DatabaseManager

db = DatabaseManager()

class PayrollCalculator:
    """حسابات الرواتب والأجور"""
    
    @staticmethod
    def calculate_attendance_salary(attendance_days, daily_wage):
        """
        حساب راتب الحضور
        Calculate attendance salary
        
        Formula: Attendance Days × Daily Wage
        """
        return attendance_days * daily_wage
    
    @staticmethod
    def calculate_overtime_salary(overtime_hours, overtime_rate):
        """
        حساب راتب الإضافي
        Calculate overtime salary
        
        Formula: Overtime Hours × Overtime Rate
        """
        return overtime_hours * overtime_rate
    
    @staticmethod
    def calculate_gross_salary(attendance_salary, overtime_salary, bonuses):
        """
        حساب الراتب الإجمالي (قبل الخصومات)
        Calculate gross salary (before deductions)
        
        Formula: Attendance Salary + Overtime Salary + Bonuses
        """
        return attendance_salary + overtime_salary + bonuses
    
    @staticmethod
    def calculate_net_salary(gross_salary, advances, deductions):
        """
        حساب صافي الراتب
        Calculate net salary
        
        Formula: Gross Salary - Advances - Deductions
        """
        return gross_salary - advances - deductions
    
    @staticmethod
    def calculate_full_payroll(employee_id, start_date, end_date):
        """
        حساب كشف راتب كامل للموظف في فترة زمنية
        Calculate complete payroll for employee in a period
        """
        conn = db.get_connection()
        cursor = conn.cursor()
        
        try:
            # الحصول على بيانات الموظف
            cursor.execute('''
                SELECT e.*, q.daily_wage, q.overtime_rate
                FROM employees e
                LEFT JOIN qualifications q ON e.qualification_id = q.id
                WHERE e.id = ?
            ''', (employee_id,))
            employee = cursor.fetchone()
            
            if not employee:
                return None
            
            # حساب أيام الحضور
            cursor.execute('''
                SELECT COUNT(*) as count FROM attendance
                WHERE employee_id = ? AND attendance_date BETWEEN ? AND ? 
                AND status = 'حاضر'
            ''', (employee_id, start_date, end_date))
            attendance_days = cursor.fetchone()[0]
            
            # حساب ساعات الإضافي
            cursor.execute('''
                SELECT COALESCE(SUM(hours), 0) as total FROM overtime
                WHERE employee_id = ? AND overtime_date BETWEEN ? AND ?
            ''', (employee_id, start_date, end_date))
            overtime_hours = cursor.fetchone()[0]
            
            # حساب السلفات
            cursor.execute('''
                SELECT COALESCE(SUM(amount), 0) as total FROM advances
                WHERE employee_id = ? AND advance_date BETWEEN ? AND ? 
                AND status = 'موافق عليها'
            ''', (employee_id, start_date, end_date))
            advances_total = cursor.fetchone()[0]
            
            # حساب الخصومات
            cursor.execute('''
                SELECT COALESCE(SUM(amount), 0) as total FROM deductions
                WHERE employee_id = ? AND deduction_date BETWEEN ? AND ?
            ''', (employee_id, start_date, end_date))
            deductions_total = cursor.fetchone()[0]
            
            # حساب المكافآت
            cursor.execute('''
                SELECT COALESCE(SUM(amount), 0) as total FROM bonuses
                WHERE employee_id = ? AND bonus_date BETWEEN ? AND ?
            ''', (employee_id, start_date, end_date))
            bonuses_total = cursor.fetchone()[0]
            
            # الحسابات النهائية
            daily_wage = employee['daily_wage'] or 0
            overtime_rate = employee['overtime_rate'] or 0
            
            attendance_salary = PayrollCalculator.calculate_attendance_salary(
                attendance_days, daily_wage
            )
            overtime_salary = PayrollCalculator.calculate_overtime_salary(
                overtime_hours, overtime_rate
            )
            gross_salary = PayrollCalculator.calculate_gross_salary(
                attendance_salary, overtime_salary, bonuses_total
            )
            net_salary = PayrollCalculator.calculate_net_salary(
                gross_salary, advances_total, deductions_total
            )
            
            return {
                'employee_id': employee_id,
                'employee_name': employee['full_name'],
                'period': f"{start_date} to {end_date}",
                'attendance_days': attendance_days,
                'overtime_hours': overtime_hours,
                'attendance_salary': attendance_salary,
                'overtime_salary': overtime_salary,
                'bonuses_total': bonuses_total,
                'advances_total': advances_total,
                'deductions_total': deductions_total,
                'gross_salary': gross_salary,
                'net_salary': net_salary
            }
            
        finally:
            conn.close()


class AttendanceHelper:
    """مساعدات الحضور والغياب"""
    
    @staticmethod
    def get_attendance_summary(start_date, end_date):
        """الحصول على ملخص الحضور"""
        conn = db.get_connection()
        cursor = conn.cursor()
        
        try:
            query = '''
                SELECT 
                    status,
                    COUNT(*) as count
                FROM attendance
                WHERE attendance_date BETWEEN ? AND ?
                GROUP BY status
            '''
            cursor.execute(query, (start_date, end_date))
            summary = {row['status']: row['count'] for row in cursor.fetchall()}
            return summary
        finally:
            conn.close()
    
    @staticmethod
    def get_employee_attendance_percentage(employee_id, start_date, end_date):
        """الحصول على نسبة حضور الموظف"""
        conn = db.get_connection()
        cursor = conn.cursor()
        
        try:
            # عدد أيام الحضور الفعلية
            cursor.execute('''
                SELECT COUNT(*) as count FROM attendance
                WHERE employee_id = ? AND attendance_date BETWEEN ? AND ? 
                AND status IN ('حاضر', 'نصف يوم')
            ''', (employee_id, start_date, end_date))
            present_days = cursor.fetchone()[0]
            
            # إجمالي أيام العمل المتوقعة
            cursor.execute('''
                SELECT COUNT(*) as count FROM attendance
                WHERE employee_id = ? AND attendance_date BETWEEN ? AND ? 
                AND status NOT IN ('إجازة', 'إجازة مرضية')
            ''', (employee_id, start_date, end_date))
            total_days = cursor.fetchone()[0]
            
            if total_days == 0:
                return 0
            
            percentage = (present_days / total_days) * 100
            return round(percentage, 2)
        finally:
            conn.close()


class DateHelper:
    """مساعدات التاريخ والوقت"""
    
    @staticmethod
    def get_month_range(year, month):
        """الحصول على أول وآخر يوم في الشهر"""
        from datetime import date
        first_day = date(year, month, 1)
        if month == 12:
            last_day = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            last_day = date(year, month + 1, 1) - timedelta(days=1)
        return first_day.isoformat(), last_day.isoformat()
    
    @staticmethod
    def get_week_range(date_str):
        """الحصول على أول وآخر يوم في الأسبوع"""
        from datetime import date, datetime
        date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
        week_start = date_obj - timedelta(days=date_obj.weekday())
        week_end = week_start + timedelta(days=6)
        return week_start.isoformat(), week_end.isoformat()
    
    @staticmethod
    def format_date_ar(date_str):
        """تنسيق التاريخ بالعربية"""
        from datetime import datetime
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        months_ar = {
            1: 'يناير', 2: 'فبراير', 3: 'مارس', 4: 'أبريل',
            5: 'مايو', 6: 'يونيو', 7: 'يوليو', 8: 'أغسطس',
            9: 'سبتمبر', 10: 'أكتوبر', 11: 'نوفمبر', 12: 'ديسمبر'
        }
        return f"{date_obj.day} {months_ar[date_obj.month]} {date_obj.year}"


class ValidationHelper:
    """مساعدات التحقق من الصحة"""
    
    @staticmethod
    def validate_email(email):
        """التحقق من صحة البريد الإلكتروني"""
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_phone(phone):
        """التحقق من صحة رقم الهاتف"""
        import re
        pattern = r'^(01)[0-9]{9}$'  # مصري
        return re.match(pattern, phone) is not None
    
    @staticmethod
    def validate_national_id(national_id):
        """التحقق من صحة الرقم القومي"""
        if not national_id or len(national_id) != 14:
            return False
        return national_id.isdigit()
    
    @staticmethod
    def validate_amount(amount):
        """التحقق من صحة المبلغ"""
        try:
            float_amount = float(amount)
            return float_amount >= 0
        except (ValueError, TypeError):
            return False


class ReportHelper:
    """مساعدات التقارير"""
    
    @staticmethod
    def prepare_payroll_report_data(start_date, end_date):
        """تحضير بيانات تقرير الرواتب"""
        conn = db.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT 
                    e.full_name,
                    e.employee_id,
                    q.name as qualification,
                    q.daily_wage,
                    COUNT(CASE WHEN a.status = 'حاضر' THEN 1 END) as attendance_days,
                    COUNT(CASE WHEN a.status = 'غائب' THEN 1 END) as absent_days,
                    COALESCE(SUM(o.hours), 0) as overtime_hours,
                    COALESCE(SUM(b.amount), 0) as bonuses,
                    COALESCE(SUM(adv.amount), 0) as advances,
                    COALESCE(SUM(d.amount), 0) as deductions
                FROM employees e
                LEFT JOIN qualifications q ON e.qualification_id = q.id
                LEFT JOIN attendance a ON e.id = a.employee_id 
                    AND a.attendance_date BETWEEN ? AND ?
                LEFT JOIN overtime o ON e.id = o.employee_id 
                    AND o.overtime_date BETWEEN ? AND ?
                LEFT JOIN bonuses b ON e.id = b.employee_id 
                    AND b.bonus_date BETWEEN ? AND ?
                LEFT JOIN advances adv ON e.id = adv.employee_id 
                    AND adv.advance_date BETWEEN ? AND ? 
                    AND adv.status = 'موافق عليها'
                LEFT JOIN deductions d ON e.id = d.employee_id 
                    AND d.deduction_date BETWEEN ? AND ?
                WHERE e.status = 'نشط'
                GROUP BY e.id
                ORDER BY e.full_name
            ''', (start_date, end_date, start_date, end_date, 
                  start_date, end_date, start_date, end_date, 
                  start_date, end_date))
            
            data = []
            for row in cursor.fetchall():
                row_dict = dict(row)
                # حساب الرواتب
                daily_wage = row_dict['daily_wage'] or 0
                attendance_salary = row_dict['attendance_days'] * daily_wage
                row_dict['attendance_salary'] = attendance_salary
                row_dict['net_salary'] = (attendance_salary + 
                                         row_dict['bonuses'] - 
                                         row_dict['advances'] - 
                                         row_dict['deductions'])
                data.append(row_dict)
            
            return data
        finally:
            conn.close()
