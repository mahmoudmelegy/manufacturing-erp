@echo off
REM ========================================
REM نظام إدارة الحضور والرواتب
REM Factory Payroll Management System
REM Startup Script for Windows
REM ========================================

chcp 65001 > nul
cls

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                                                                ║
echo ║        نظام إدارة الحضور والرواتب - نسخة 1.0.0              ║
echo ║       Factory Payroll Management System - Version 1.0.0       ║
echo ║                                                                ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ خطأ: Python غير مثبت!
    echo ❌ Error: Python is not installed!
    echo.
    echo ⚠️ الرجاء تثبيت Python 3.8 أو أعلى من: https://www.python.org
    echo ⚠️ Please install Python 3.8 or higher from: https://www.python.org
    pause
    exit /b 1
)

REM Check if Node.js is installed
node --version >nul 2>&1
if errorlevel 1 (
    echo ⚠️ تحذير: Node.js غير مثبت / Warning: Node.js is not installed
    echo.
    echo معلومة: سيتم تشغيل خادم الويب فقط (بدون الواجهة الرسومية)
    echo Info: Only the API server will run (without the web interface)
) else (
    echo ✓ Node.js مثبت / Node.js is installed
)

echo.
echo جاري تحضير التطبيق / Preparing application...
echo.

REM Create logs directory if it doesn't exist
if not exist "logs" mkdir logs

REM Initialize database if needed
echo 🔧 تهيئة قاعدة البيانات / Initializing database...
python database.py

if errorlevel 1 (
    echo ❌ خطأ في تهيئة قاعدة البيانات / Database initialization error
    pause
    exit /b 1
)

echo ✓ تم تهيئة قاعدة البيانات بنجاح / Database initialized successfully
echo.

REM Start Flask backend
echo 🚀 بدء تشغيل خادم الويب / Starting backend server...
echo.

start "Factory Payroll - Backend Server" cmd /k python app.py

REM Wait for Flask to start
timeout /t 3 /nobreak

REM Check if Flask started successfully
netstat -ano | find ":5000" >nul
if %errorlevel% equ 0 (
    echo ✓ خادم الويب يعمل على: http://127.0.0.1:5000
    echo ✓ Backend server is running at: http://127.0.0.1:5000
) else (
    echo ⚠️ تحذير: قد لا يعمل خادم الويب بشكل صحيح
    echo ⚠️ Warning: Backend server might not be running correctly
)

echo.

REM Start React frontend if npm is available
npm --version >nul 2>&1
if errorlevel 1 (
    echo ℹ️ لتشغيل الواجهة الرسومية:
    echo ℹ️ To run the web interface:
    echo.
    echo   1. افتح نافذة Command Prompt جديدة / Open a new Command Prompt
    echo   2. اذهب إلى مجلد المشروع / Navigate to project directory
    echo   3. اكتب: npm start
    echo   4. انتقل إلى: http://localhost:3000
    echo.
) else (
    echo 🚀 بدء تشغيل الواجهة الرسومية / Starting frontend...
    echo.
    
    REM Install dependencies if needed
    if not exist "node_modules" (
        echo 📦 تثبيت المكتبات / Installing dependencies...
        call npm install
        
        if errorlevel 1 (
            echo ❌ خطأ في تثبيت المكتبات / Error installing dependencies
            pause
            exit /b 1
        )
    )
    
    REM Start npm in a new window
    start "Factory Payroll - Frontend" cmd /k npm start
    
    echo ✓ سيتم فتح الواجهة تلقائياً في متصفحك
    echo ✓ The interface will open in your browser automatically
)

echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║                      التطبيق جاهز للاستخدام                      ║
echo ║                   Application is ready to use!                 ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.
echo 📱 الواجهة الرسومية: http://localhost:3000
echo 📱 Web Interface: http://localhost:3000
echo.
echo 🔌 خادم الويب: http://127.0.0.1:5000
echo 🔌 API Server: http://127.0.0.1:5000
echo.
echo 👤 بيانات الدخول الافتراضية / Default Credentials:
echo    اسم المستخدم / Username: admin
echo    كلمة المرور / Password: admin123
echo.
echo ⚠️  ملاحظة: لا تغلق نوافذ الأوامر / Note: Do not close the command windows
echo    هذا سيؤدي إلى إيقاف التطبيق / This will stop the application
echo.
echo 💾 تلميحات مهمة / Important Tips:
echo    • احفظ نسخة احتياطية من البيانات يومياً
echo    • Save database backups daily
echo    • استخدم صلاحيات الدخول المناسبة
echo    • Use appropriate user roles
echo    • تجنب غلق التطبيق أثناء العمليات الحساسة
echo    • Avoid closing while processing data
echo.
echo اضغط أي مفتاح للمتابعة / Press any key to continue...
pause >nul

goto :eof
