/**
 * خدمة الـ API للتواصل مع الخادم
 * API Service for Backend Communication
 */

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

class ApiService {
  constructor() {
    this.token = localStorage.getItem('token');
  }

  setToken(token) {
    this.token = token;
    localStorage.setItem('token', token);
  }

  getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`
    };
  }

  async request(endpoint, method = 'GET', data = null) {
    try {
      const options = {
        method,
        headers: this.getHeaders(),
      };

      if (data) {
        options.body = JSON.stringify(data);
      }

      const response = await fetch(`${API_URL}${endpoint}`, options);

      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('token');
          window.location.href = '/login';
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // ==================== Authentication ====================
  async login(username, password) {
    return this.request('/auth/login', 'POST', { username, password });
  }

  // ==================== Employees ====================
  async getEmployees(search = '', departmentId = null) {
    let url = '/employees';
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (departmentId) params.append('department_id', departmentId);
    if (params.toString()) url += `?${params.toString()}`;
    return this.request(url);
  }

  async getEmployee(id) {
    return this.request(`/employees/${id}`);
  }

  async addEmployee(data) {
    return this.request('/employees', 'POST', data);
  }

  async updateEmployee(id, data) {
    return this.request(`/employees/${id}`, 'PUT', data);
  }

  async deleteEmployee(id) {
    return this.request(`/employees/${id}`, 'DELETE');
  }

  // ==================== Qualifications ====================
  async getQualifications() {
    return this.request('/qualifications');
  }

  async addQualification(data) {
    return this.request('/qualifications', 'POST', data);
  }

  async updateQualification(id, data) {
    return this.request(`/qualifications/${id}`, 'PUT', data);
  }

  async deleteQualification(id) {
    return this.request(`/qualifications/${id}`, 'DELETE');
  }

  // ==================== Departments ====================
  async getDepartments() {
    return this.request('/departments');
  }

  async addDepartment(data) {
    return this.request('/departments', 'POST', data);
  }

  async updateDepartment(id, data) {
    return this.request(`/departments/${id}`, 'PUT', data);
  }

  async deleteDepartment(id) {
    return this.request(`/departments/${id}`, 'DELETE');
  }

  // ==================== Attendance ====================
  async getAttendance(date = null, employeeId = null) {
    let url = '/attendance';
    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (employeeId) params.append('employee_id', employeeId);
    if (params.toString()) url += `?${params.toString()}`;
    return this.request(url);
  }

  async recordAttendance(data) {
    return this.request('/attendance', 'POST', data);
  }

  // ==================== Overtime ====================
  async getOvertime(month = null) {
    let url = '/overtime';
    if (month) url += `?month=${month}`;
    return this.request(url);
  }

  async addOvertime(data) {
    return this.request('/overtime', 'POST', data);
  }

  // ==================== Advances ====================
  async getAdvances(employeeId = null, status = null) {
    let url = '/advances';
    const params = new URLSearchParams();
    if (employeeId) params.append('employee_id', employeeId);
    if (status) params.append('status', status);
    if (params.toString()) url += `?${params.toString()}`;
    return this.request(url);
  }

  async addAdvance(data) {
    return this.request('/advances', 'POST', data);
  }

  // ==================== Deductions ====================
  async getDeductions(employeeId = null) {
    let url = '/deductions';
    if (employeeId) url += `?employee_id=${employeeId}`;
    return this.request(url);
  }

  async addDeduction(data) {
    return this.request('/deductions', 'POST', data);
  }

  // ==================== Bonuses ====================
  async getBonuses(employeeId = null) {
    let url = '/bonuses';
    if (employeeId) url += `?employee_id=${employeeId}`;
    return this.request(url);
  }

  async addBonus(data) {
    return this.request('/bonuses', 'POST', data);
  }

  // ==================== Payroll ====================
  async calculatePayroll(data) {
    return this.request('/payroll/calculate', 'POST', data);
  }

  async getPayroll() {
    return this.request('/payroll');
  }

  // ==================== Dashboard ====================
  async getDashboard() {
    return this.request('/dashboard');
  }

  // ==================== Settings ====================
  async getSettings() {
    return this.request('/settings');
  }

  async updateSettings(data) {
    return this.request('/settings', 'PUT', data);
  }

  // ==================== Backup ====================
  async createBackup() {
    return this.request('/backup', 'POST');
  }
}

export default new ApiService();
