import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../styles/sidebar.css';

function Sidebar({ user, onLogout, darkMode, onToggleDarkMode }) {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  const menuItems = [
    { path: '/', label: 'لوحة التحكم', icon: '📊' },
    { path: '/employees', label: 'الموظفين', icon: '👥' },
    { path: '/qualifications', label: 'المؤهلات', icon: '📚' },
    { path: '/departments', label: 'الأقسام', icon: '🏢' },
    { path: '/attendance', label: 'الحضور والغياب', icon: '📋' },
    { path: '/overtime', label: 'الإضافي', icon: '⏰' },
    { path: '/advances', label: 'السلفات', icon: '💰' },
    { path: '/deductions', label: 'الخصومات', icon: '📉' },
    { path: '/bonuses', label: 'المكافآت', icon: '🎁' },
    { path: '/payroll', label: 'كشوف الرواتب', icon: '💵' },
    { path: '/reports', label: 'التقارير', icon: '📈' },
    { path: '/settings', label: 'الإعدادات', icon: '⚙️' },
  ];

  return (
    <aside className={`sidebar ${isOpen ? 'open' : 'closed'}`}>
      <div className="sidebar-header">
        <div className="logo">
          <span className="logo-icon">🏭</span>
          {isOpen && <span className="logo-text">مصنع</span>}
        </div>
        <button 
          className="toggle-btn" 
          onClick={() => setIsOpen(!isOpen)}
          title="فتح/إغلاق القائمة"
        >
          {isOpen ? '◀' : '▶'}
        </button>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`nav-item ${isActive(item.path) ? 'active' : ''}`}
            title={item.label}
          >
            <span className="nav-icon">{item.icon}</span>
            {isOpen && <span className="nav-label">{item.label}</span>}
          </Link>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="user-info">
          {isOpen && (
            <div className="user-details">
              <p className="user-name">{user?.full_name}</p>
              <p className="user-role">{user?.role}</p>
            </div>
          )}
        </div>

        <button
          className="theme-toggle"
          onClick={onToggleDarkMode}
          title={darkMode ? 'الوضع الفاتح' : 'الوضع الليلي'}
        >
          {darkMode ? '☀️' : '🌙'}
        </button>

        <button
          className="logout-btn"
          onClick={onLogout}
          title="تسجيل الخروج"
        >
          {isOpen ? '🚪 تسجيل خروج' : '🚪'}
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;
