// ==================== Departments.jsx ====================
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/departments.css';

function Departments() {
  const [departments, setDepartments] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    name: '',
    manager_name: '',
    description: ''
  });

  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    try {
      const data = await api.getDepartments();
      setDepartments(data);
    } catch (error) {
      alert('خطأ: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.updateDepartment(editingId, formData);
        alert('تم تحديث القسم بنجاح');
      } else {
        await api.addDepartment(formData);
        alert('تم إضافة القسم بنجاح');
      }
      resetForm();
      fetchDepartments();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleEdit = (dept) => {
    setFormData(dept);
    setEditingId(dept.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا القسم؟')) {
      try {
        await api.deleteDepartment(id);
        alert('تم حذف القسم بنجاح');
        fetchDepartments();
      } catch (error) {
        alert('خطأ: ' + error.message);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      manager_name: '',
      description: ''
    });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>إدارة الأقسام</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          ➕ إضافة قسم جديد
        </button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-content">
            <h2>{editingId ? 'تعديل القسم' : 'إضافة قسم جديد'}</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>اسم القسم *</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="مثلاً: الإنتاج"
                  required
                />
              </div>

              <div className="form-group">
                <label>مدير القسم</label>
                <input
                  type="text"
                  name="manager_name"
                  value={formData.manager_name}
                  onChange={handleInputChange}
                  placeholder="اسم مدير القسم"
                />
              </div>

              <div className="form-group full-width">
                <label>الوصف</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="وصف القسم"
                  rows="3"
                ></textarea>
              </div>

              <div className="form-actions">
                <button type="submit" className="btn-save">💾 حفظ</button>
                <button type="button" className="btn-cancel" onClick={resetForm}>❌ إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading">جاري تحميل البيانات...</div>
      ) : (
        <div className="departments-grid">
          {departments.map(dept => (
            <div key={dept.id} className="department-card">
              <div className="card-header">
                <h3>{dept.name}</h3>
                <div className="card-actions">
                  <button className="btn-edit" onClick={() => handleEdit(dept)}>✏️</button>
                  <button className="btn-delete" onClick={() => handleDelete(dept.id)}>🗑️</button>
                </div>
              </div>
              <div className="card-body">
                <div className="info-row">
                  <span className="label">👤 مدير القسم:</span>
                  <span className="value">{dept.manager_name || '-'}</span>
                </div>
                {dept.description && (
                  <p className="description">{dept.description}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Departments;


// ==================== Attendance.jsx ====================
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/attendance.css';

function Attendance() {
  const [attendance, setAttendance] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [selectedDate]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [attData, empData] = await Promise.all([
        api.getAttendance(selectedDate),
        api.getEmployees()
      ]);
      setAttendance(attData);
      setEmployees(empData);
    } catch (error) {
      alert('خطأ: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAttendanceChange = async (employeeId, status) => {
    try {
      await api.recordAttendance({
        employee_id: employeeId,
        attendance_date: selectedDate,
        status: status
      });
      fetchData();
      alert('تم تسجيل الحضور بنجاح');
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const attendanceStatuses = ['حاضر', 'غائب', 'نصف يوم', 'إجازة', 'إجازة مرضية'];

  const getStatusColor = (status) => {
    switch (status) {
      case 'حاضر': return '#10b981';
      case 'غائب': return '#ef4444';
      case 'نصف يوم': return '#f59e0b';
      case 'إجازة': return '#3b82f6';
      case 'إجازة مرضية': return '#8b5cf6';
      default: return '#6b7280';
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>تسجيل الحضور والغياب</h1>
        <div className="date-picker-container">
          <label>اختر التاريخ:</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="date-input"
          />
        </div>
      </div>

      {loading ? (
        <div className="loading">جاري التحميل...</div>
      ) : (
        <div className="attendance-container">
          <div className="attendance-table-wrapper">
            <table className="attendance-table">
              <thead>
                <tr>
                  <th>معرف الموظف</th>
                  <th>اسم الموظف</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => {
                  const attRecord = attendance.find(a => a.employee_id === emp.id);
                  const currentStatus = attRecord?.status || 'حاضر';
                  return (
                    <tr key={emp.id}>
                      <td>{emp.employee_id}</td>
                      <td>{emp.full_name}</td>
                      <td>
                        <select
                          value={currentStatus}
                          onChange={(e) => handleAttendanceChange(emp.id, e.target.value)}
                          className="status-select"
                          style={{ borderColor: getStatusColor(currentStatus) }}
                        >
                          {attendanceStatuses.map(status => (
                            <option key={status} value={status}>{status}</option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="attendance-summary">
            <h3>ملخص اليوم</h3>
            <div className="summary-cards">
              <div className="summary-card present">
                <span className="count">{attendance.filter(a => a.status === 'حاضر').length}</span>
                <span className="label">حاضرين</span>
              </div>
              <div className="summary-card absent">
                <span className="count">{attendance.filter(a => a.status === 'غائب').length}</span>
                <span className="label">غائبين</span>
              </div>
              <div className="summary-card half-day">
                <span className="count">{attendance.filter(a => a.status === 'نصف يوم').length}</span>
                <span className="label">نصف يوم</span>
              </div>
              <div className="summary-card vacation">
                <span className="count">{attendance.filter(a => a.status === 'إجازة').length}</span>
                <span className="label">إجازة</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Attendance;


// ==================== Overtime.jsx ====================
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/overtime.css';

function Overtime() {
  const [overtime, setOvertime] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    employee_id: '',
    overtime_date: new Date().toISOString().split('T')[0],
    hours: '',
    notes: ''
  });

  useEffect(() => {
    fetchData();
  }, [selectedMonth]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [otData, empData] = await Promise.all([
        api.getOvertime(selectedMonth),
        api.getEmployees()
      ]);
      setOvertime(otData);
      setEmployees(empData);
    } catch (error) {
      alert('خطأ: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.addOvertime(formData);
      alert('تم إضافة الإضافي بنجاح');
      resetForm();
      fetchData();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      employee_id: '',
      overtime_date: new Date().toISOString().split('T')[0],
      hours: '',
      notes: ''
    });
    setShowForm(false);
  };

  const getTotalOvertimeHours = () => {
    return overtime.reduce((sum, ot) => sum + ot.hours, 0);
  };

  const getTotalOvertimeCost = () => {
    return overtime.reduce((sum, ot) => sum + (ot.hours * (ot.overtime_rate || 0)), 0);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>إدارة الإضافي</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          ➕ إضافة إضافي
        </button>
      </div>

      <div className="month-filter">
        <label>اختر الشهر:</label>
        <input
          type="month"
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(e.target.value)}
        />
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-content">
            <h2>إضافة ساعات إضافية</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>الموظف *</label>
                <select
                  name="employee_id"
                  value={formData.employee_id}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">اختر موظف</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.full_name}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>التاريخ *</label>
                <input
                  type="date"
                  name="overtime_date"
                  value={formData.overtime_date}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-group">
                <label>عدد الساعات *</label>
                <input
                  type="number"
                  name="hours"
                  value={formData.hours}
                  onChange={handleInputChange}
                  placeholder="0"
                  step="0.5"
                  required
                />
              </div>

              <div className="form-group">
                <label>ملاحظات</label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  placeholder="ملاحظات إضافية"
                  rows="2"
                ></textarea>
              </div>

              <div className="form-actions">
                <button type="submit" className="btn-save">💾 حفظ</button>
                <button type="button" className="btn-cancel" onClick={resetForm}>❌ إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading">جاري التحميل...</div>
      ) : (
        <>
          <div className="overtime-summary">
            <div className="summary-card">
              <span className="label">إجمالي الساعات</span>
              <span className="value">{getTotalOvertimeHours().toFixed(1)}</span>
              <span className="unit">ساعة</span>
            </div>
            <div className="summary-card">
              <span className="label">إجمالي التكلفة</span>
              <span className="value">{getTotalOvertimeCost().toFixed(2)}</span>
              <span className="unit">﷼</span>
            </div>
          </div>

          <div className="overtime-table-container">
            <table className="overtime-table">
              <thead>
                <tr>
                  <th>الموظف</th>
                  <th>التاريخ</th>
                  <th>الساعات</th>
                  <th>المعدل</th>
                  <th>المبلغ</th>
                </tr>
              </thead>
              <tbody>
                {overtime.length > 0 ? (
                  overtime.map(ot => (
                    <tr key={ot.id}>
                      <td>{ot.full_name}</td>
                      <td>{new Date(ot.overtime_date).toLocaleDateString('ar-EG')}</td>
                      <td>{ot.hours}</td>
                      <td>{ot.overtime_rate} ﷼</td>
                      <td>{(ot.hours * ot.overtime_rate).toFixed(2)} ﷼</td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan="5" className="no-data">لا توجد بيانات</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

export default Overtime;
