// Departments.jsx
import React, { useState, useEffect } from 'react';
import api from '../services/api';

function Departments() {
  const [departments, setDepartments] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ name: '', manager_name: '', description: '' });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const data = await api.getDepartments();
      setDepartments(data);
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.updateDepartment(editingId, formData);
      } else {
        await api.addDepartment(formData);
      }
      resetForm();
      fetchData();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', manager_name: '', description: '' });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (dept) => {
    setFormData(dept);
    setEditingId(dept.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد؟')) {
      try {
        await api.deleteDepartment(id);
        fetchData();
      } catch (error) {
        alert('خطأ: ' + error.message);
      }
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>إدارة الأقسام</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          ➕ إضافة قسم جديد
        </button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-content">
            <h2>{editingId ? 'تعديل القسم' : 'إضافة قسم جديد'}</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>اسم القسم *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label>مدير القسم</label>
                <input
                  type="text"
                  value={formData.manager_name}
                  onChange={(e) => setFormData({...formData, manager_name: e.target.value})}
                />
              </div>
              <div className="form-group full-width">
                <label>الوصف</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows="3"
                ></textarea>
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-save">💾 حفظ</button>
                <button type="button" className="btn-cancel" onClick={resetForm}>❌ إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="departments-grid">
        {departments.map(dept => (
          <div key={dept.id} className="department-card">
            <h3>{dept.name}</h3>
            <p className="manager">👤 {dept.manager_name || '-'}</p>
            <p className="description">{dept.description}</p>
            <div className="card-actions">
              <button className="btn-edit" onClick={() => handleEdit(dept)}>✏️</button>
              <button className="btn-delete" onClick={() => handleDelete(dept.id)}>🗑️</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Departments;


// Attendance.jsx
import React, { useState, useEffect } from 'react';
import api from '../services/api';

function Attendance() {
  const [attendance, setAttendance] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [selectedDate]);

  const fetchData = async () => {
    try {
      const [attData, empData] = await Promise.all([
        api.getAttendance(selectedDate),
        api.getEmployees()
      ]);
      setAttendance(attData);
      setEmployees(empData);
    } catch (error) {
      alert('خطأ: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAttendanceChange = async (employeeId, status) => {
    try {
      await api.recordAttendance({
        employee_id: employeeId,
        attendance_date: selectedDate,
        status: status
      });
      fetchData();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const attendanceStatuses = ['حاضر', 'غائب', 'نصف يوم', 'إجازة', 'إجازة مرضية'];

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>تسجيل الحضور والغياب</h1>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="date-input"
        />
      </div>

      {loading ? (
        <div className="loading">جاري التحميل...</div>
      ) : (
        <div className="attendance-table-container">
          <table className="attendance-table">
            <thead>
              <tr>
                <th>اسم الموظف</th>
                <th>المعرف</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {employees.map(emp => {
                const attRecord = attendance.find(a => a.employee_id === emp.id);
                return (
                  <tr key={emp.id}>
                    <td>{emp.full_name}</td>
                    <td>{emp.employee_id}</td>
                    <td>
                      <select
                        value={attRecord?.status || 'حاضر'}
                        onChange={(e) => handleAttendanceChange(emp.id, e.target.value)}
                      >
                        {attendanceStatuses.map(status => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Attendance;


// Payroll.jsx
import React, { useState, useEffect } from 'react';
import api from '../services/api';

function Payroll() {
  const [payrollData, setPayrollData] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [period, setPeriod] = useState('');
  const [periodType, setPeriodType] = useState('شهري');

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const data = await api.getEmployees();
      setEmployees(data);
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleCalculatePayroll = async () => {
    if (!selectedEmployee || !period) {
      alert('اختر موظف وفترة زمنية');
      return;
    }

    try {
      const result = await api.calculatePayroll({
        employee_id: selectedEmployee,
        period: period,
        period_type: periodType
      });
      alert('تم حساب الراتب بنجاح');
      fetchPayroll();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const fetchPayroll = async () => {
    try {
      const data = await api.getPayroll();
      setPayrollData(data);
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  useEffect(() => {
    fetchPayroll();
  }, []);

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>كشوف الرواتب</h1>
      </div>

      <div className="payroll-calculator">
        <select
          value={selectedEmployee}
          onChange={(e) => setSelectedEmployee(e.target.value)}
        >
          <option value="">اختر موظف</option>
          {employees.map(emp => (
            <option key={emp.id} value={emp.id}>{emp.full_name}</option>
          ))}
        </select>

        <input
          type="text"
          placeholder="من التاريخ إلى التاريخ (YYYY-MM-DD to YYYY-MM-DD)"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
        />

        <select value={periodType} onChange={(e) => setPeriodType(e.target.value)}>
          <option value="شهري">شهري</option>
          <option value="أسبوعي">أسبوعي</option>
        </select>

        <button className="btn-primary" onClick={handleCalculatePayroll}>
          حساب الراتب
        </button>
      </div>

      <table className="payroll-table">
        <thead>
          <tr>
            <th>الموظف</th>
            <th>الفترة</th>
            <th>صافي الراتب</th>
            <th>الحالة</th>
          </tr>
        </thead>
        <tbody>
          {payrollData.map(payroll => (
            <tr key={payroll.id}>
              <td>{payroll.employee_name}</td>
              <td>{payroll.payroll_period}</td>
              <td>{payroll.net_salary} ﷼</td>
              <td>{payroll.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Payroll;


// Reports.jsx
import React, { useState } from 'react';

function Reports() {
  const [selectedReport, setSelectedReport] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const reportTypes = [
    { id: 'attendance', name: 'تقرير الحضور' },
    { id: 'absence', name: 'تقرير الغياب' },
    { id: 'overtime', name: 'تقرير الإضافي' },
    { id: 'advances', name: 'تقرير السلفات' },
    { id: 'deductions', name: 'تقرير الخصومات' },
    { id: 'bonuses', name: 'تقرير المكافآت' },
    { id: 'payroll', name: 'تقرير الرواتب' },
  ];

  const handleGenerateReport = () => {
    if (!selectedReport || !startDate || !endDate) {
      alert('اختر التقرير والفترة الزمنية');
      return;
    }
    alert(`جاري إنشاء: ${selectedReport}`);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>التقارير</h1>
      </div>

      <div className="reports-container">
        <div className="report-selector">
          <h2>اختر التقرير</h2>
          <div className="report-options">
            {reportTypes.map(report => (
              <button
                key={report.id}
                className={`report-option ${selectedReport === report.id ? 'active' : ''}`}
                onClick={() => setSelectedReport(report.id)}
              >
                {report.name}
              </button>
            ))}
          </div>
        </div>

        <div className="report-settings">
          <h2>إعدادات التقرير</h2>
          <div className="date-range">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              placeholder="من"
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              placeholder="إلى"
            />
          </div>

          <div className="export-options">
            <button className="btn-primary" onClick={handleGenerateReport}>
              📊 إنشاء التقرير
            </button>
            <button className="btn-secondary">
              📄 تصدير PDF
            </button>
            <button className="btn-secondary">
              📊 تصدير Excel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Reports;


// Settings.jsx
import React, { useState, useEffect } from 'react';
import api from '../services/api';

function Settings() {
  const [settings, setSettings] = useState({
    company_name: '',
    factory_name: '',
    currency: 'EGP',
    currency_symbol: '﷼'
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await api.getSettings();
      setSettings(data);
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    try {
      await api.updateSettings(settings);
      alert('تم حفظ الإعدادات بنجاح');
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleBackup = async () => {
    try {
      const result = await api.createBackup();
      alert(`تم إنشاء نسخة احتياطية: ${result.file}`);
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>الإعدادات</h1>
      </div>

      <div className="settings-container">
        <div className="settings-section">
          <h2>معلومات الشركة والمصنع</h2>
          <div className="form-group">
            <label>اسم الشركة</label>
            <input
              type="text"
              name="company_name"
              value={settings.company_name}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>اسم المصنع</label>
            <input
              type="text"
              name="factory_name"
              value={settings.factory_name}
              onChange={handleChange}
            />
          </div>

          <button className="btn-save" onClick={handleSave}>💾 حفظ</button>
        </div>

        <div className="settings-section">
          <h2>النسخ الاحتياطي</h2>
          <button className="btn-primary" onClick={handleBackup}>
            💾 إنشاء نسخة احتياطية
          </button>
        </div>

        <div className="settings-section">
          <h2>عن البرنامج</h2>
          <p>نظام إدارة الحضور والرواتب v1.0.0</p>
          <p>جميع الحقوق محفوظة © 2024</p>
        </div>
      </div>
    </div>
  );
}

export default Settings;
