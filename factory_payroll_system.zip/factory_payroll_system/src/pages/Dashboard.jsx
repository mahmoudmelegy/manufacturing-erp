import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/dashboard.css';

function Dashboard() {
  const [stats, setStats] = useState({
    total_workers: 0,
    present_today: 0,
    absent_today: 0,
    weekly_payroll: 0,
    monthly_payroll: 0,
    total_overtime: 0,
    total_advances: 0,
    total_deductions: 0,
    recent_activities: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const data = await api.getDashboard();
      setStats(data);
    } catch (error) {
      console.error('خطأ في تحميل بيانات لوحة التحكم:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ title, value, icon, color }) => (
    <div className={`stat-card ${color}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-content">
        <p className="stat-title">{title}</p>
        <p className="stat-value">{value.toLocaleString('ar-EG')}</p>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="page-container">
        <div className="loading">جاري تحميل البيانات...</div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>لوحة التحكم</h1>
        <p>ملخص إحصائيات العاملين والرواتب</p>
      </div>

      {/* الإحصائيات الرئيسية */}
      <div className="stats-grid">
        <StatCard
          title="إجمالي العاملين"
          value={stats.total_workers}
          icon="👥"
          color="blue"
        />
        <StatCard
          title="الحاضرين اليوم"
          value={stats.present_today}
          icon="✅"
          color="green"
        />
        <StatCard
          title="الغائبين اليوم"
          value={stats.absent_today}
          icon="❌"
          color="red"
        />
        <StatCard
          title="رواتب الأسبوع"
          value={stats.weekly_payroll}
          icon="💵"
          color="purple"
        />
        <StatCard
          title="رواتب الشهر"
          value={stats.monthly_payroll}
          icon="💰"
          color="orange"
        />
        <StatCard
          title="ساعات الإضافي"
          value={stats.total_overtime}
          icon="⏰"
          color="cyan"
        />
        <StatCard
          title="إجمالي السلفات"
          value={stats.total_advances}
          icon="📊"
          color="yellow"
        />
        <StatCard
          title="إجمالي الخصومات"
          value={stats.total_deductions}
          icon="📉"
          color="pink"
        />
      </div>

      {/* النشاطات الأخيرة */}
      <div className="recent-activities-section">
        <h2>آخر النشاطات</h2>
        <div className="activities-list">
          {stats.recent_activities && stats.recent_activities.length > 0 ? (
            stats.recent_activities.map((activity, index) => (
              <div key={index} className="activity-item">
                <div className="activity-icon">📝</div>
                <div className="activity-content">
                  <p className="activity-description">{activity.description}</p>
                  <p className="activity-meta">
                    {activity.full_name} - {new Date(activity.created_at).toLocaleString('ar-EG')}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="no-activities">لا توجد أنشطة حالياً</p>
          )}
        </div>
      </div>

      {/* بطاقات المعلومات */}
      <div className="info-cards">
        <div className="info-card">
          <h3>🔔 إشعارات مهمة</h3>
          <ul>
            <li>تأكد من تحديث بيانات الموظفين</li>
            <li>لا تنسَ إنشاء كشف الراتب الشهري</li>
            <li>قم بالنسخ الاحتياطية بانتظام</li>
          </ul>
        </div>

        <div className="info-card">
          <h3>📋 نصائح الاستخدام</h3>
          <ul>
            <li>استخدم البحث السريع للعثور على الموظفين</li>
            <li>قم بتصدير التقارير بصيغة PDF/Excel</li>
            <li>احفظ نسخة احتياطية يومياً من البيانات</li>
          </ul>
        </div>

        <div className="info-card">
          <h3>⚡ الميزات الجديدة</h3>
          <ul>
            <li>دعم كامل للغة العربية</li>
            <li>وضع ليلي محسّن للعين</li>
            <li>تصدير التقارير بجودة عالية</li>
          </ul>
        </div>
      </div>

      {/* الإحصائيات المتقدمة */}
      <div className="advanced-stats">
        <div className="chart-placeholder">
          <h3>التوزيع الشهري للرواتب</h3>
          <p>📈 الرسم البياني سيتم إضافته قريباً</p>
        </div>

        <div className="chart-placeholder">
          <h3>توزيع الموظفين حسب الأقسام</h3>
          <p>📊 الرسم البياني سيتم إضافته قريباً</p>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
