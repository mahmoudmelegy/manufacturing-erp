import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/qualifications.css';

function Qualifications() {
  const [qualifications, setQualifications] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    name: '',
    daily_wage: '',
    overtime_rate: '',
    description: ''
  });

  useEffect(() => {
    fetchQualifications();
  }, []);

  const fetchQualifications = async () => {
    try {
      const data = await api.getQualifications();
      setQualifications(data);
    } catch (error) {
      alert('خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.updateQualification(editingId, formData);
        alert('تم تحديث المؤهل بنجاح');
      } else {
        await api.addQualification(formData);
        alert('تم إضافة المؤهل بنجاح');
      }
      resetForm();
      fetchQualifications();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleEdit = (qualification) => {
    setFormData(qualification);
    setEditingId(qualification.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المؤهل؟')) {
      try {
        await api.deleteQualification(id);
        alert('تم حذف المؤهل بنجاح');
        fetchQualifications();
      } catch (error) {
        alert('خطأ: ' + error.message);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      daily_wage: '',
      overtime_rate: '',
      description: ''
    });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>إدارة المؤهلات والدرجات</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          ➕ إضافة مؤهل جديد
        </button>
      </div>

      {showForm && (
        <div className="form-modal">
          <div className="form-content">
            <h2>{editingId ? 'تعديل المؤهل' : 'إضافة مؤهل جديد'}</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>اسم المؤهل *</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="مثلاً: درجة جامعية"
                  required
                />
              </div>

              <div className="form-group">
                <label>أجرة اليوم الواحد (﷼) *</label>
                <input
                  type="number"
                  name="daily_wage"
                  value={formData.daily_wage}
                  onChange={handleInputChange}
                  placeholder="مثلاً: 300"
                  step="0.01"
                  required
                />
              </div>

              <div className="form-group">
                <label>معدل الساعة الإضافية (﷼) *</label>
                <input
                  type="number"
                  name="overtime_rate"
                  value={formData.overtime_rate}
                  onChange={handleInputChange}
                  placeholder="مثلاً: 18"
                  step="0.01"
                  required
                />
              </div>

              <div className="form-group">
                <label>الوصف</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="وصف المؤهل"
                  rows="3"
                ></textarea>
              </div>

              <div className="form-actions">
                <button type="submit" className="btn-save">💾 حفظ</button>
                <button type="button" className="btn-cancel" onClick={resetForm}>❌ إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="loading">جاري تحميل البيانات...</div>
      ) : (
        <div className="qualifications-grid">
          {qualifications.length > 0 ? (
            qualifications.map(qual => (
              <div key={qual.id} className="qualification-card">
                <div className="card-header">
                  <h3>{qual.name}</h3>
                  <div className="card-actions">
                    <button className="btn-edit" onClick={() => handleEdit(qual)}>✏️</button>
                    <button className="btn-delete" onClick={() => handleDelete(qual.id)}>🗑️</button>
                  </div>
                </div>
                <div className="card-body">
                  <div className="wage-info">
                    <span className="label">أجرة اليوم:</span>
                    <span className="value">{qual.daily_wage} ﷼</span>
                  </div>
                  <div className="wage-info">
                    <span className="label">الإضافي:</span>
                    <span className="value">{qual.overtime_rate} ﷼/الساعة</span>
                  </div>
                  {qual.description && (
                    <p className="description">{qual.description}</p>
                  )}
                </div>
              </div>
            ))
          ) : (
            <p className="no-data">لا توجد مؤهلات</p>
          )}
        </div>
      )}
    </div>
  );
}

export default Qualifications;
