import React, { useState, useEffect } from 'react';
import api from '../services/api';
import '../styles/employees.css';

function Employees() {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [qualifications, setQualifications] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    employee_id: '',
    full_name: '',
    national_id: '',
    mobile_number: '',
    department_id: '',
    qualification_id: '',
    job_title: '',
    hiring_date: '',
    status: 'نشط',
    notes: ''
  });

  useEffect(() => {
    fetchData();
  }, [search, selectedDepartment]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [empData, deptData, qualData] = await Promise.all([
        api.getEmployees(search, selectedDepartment || null),
        api.getDepartments(),
        api.getQualifications()
      ]);
      setEmployees(empData);
      setDepartments(deptData);
      setQualifications(qualData);
    } catch (error) {
      console.error('خطأ في تحميل البيانات:', error);
      alert('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await api.updateEmployee(editingId, formData);
        alert('تم تحديث الموظف بنجاح');
      } else {
        await api.addEmployee(formData);
        alert('تم إضافة الموظف بنجاح');
      }
      resetForm();
      fetchData();
    } catch (error) {
      alert('خطأ: ' + error.message);
    }
  };

  const handleEdit = (employee) => {
    setFormData(employee);
    setEditingId(employee.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الموظف؟')) {
      try {
        await api.deleteEmployee(id);
        alert('تم حذف الموظف بنجاح');
        fetchData();
      } catch (error) {
        alert('خطأ: ' + error.message);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      employee_id: '',
      full_name: '',
      national_id: '',
      mobile_number: '',
      department_id: '',
      qualification_id: '',
      job_title: '',
      hiring_date: '',
      status: 'نشط',
      notes: ''
    });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>إدارة الموظفين</h1>
        <button className="btn-primary" onClick={() => setShowForm(true)}>
          ➕ إضافة موظف جديد
        </button>
      </div>

      {/* شريط البحث والتصفية */}
      <div className="search-filter-bar">
        <input
          type="text"
          placeholder="ابحث عن موظف..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
        />
        <select
          value={selectedDepartment}
          onChange={(e) => setSelectedDepartment(e.target.value)}
          className="filter-select"
        >
          <option value="">جميع الأقسام</option>
          {departments.map(dept => (
            <option key={dept.id} value={dept.id}>{dept.name}</option>
          ))}
        </select>
      </div>

      {/* نموذج الإضافة/التعديل */}
      {showForm && (
        <div className="form-modal">
          <div className="form-content">
            <h2>{editingId ? 'تعديل الموظف' : 'إضافة موظف جديد'}</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label>معرف الموظف *</label>
                  <input
                    type="text"
                    name="employee_id"
                    value={formData.employee_id}
                    onChange={handleInputChange}
                    placeholder="مثلاً: E001"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>الاسم الكامل *</label>
                  <input
                    type="text"
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleInputChange}
                    placeholder="أدخل الاسم الكامل"
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>الرقم القومي</label>
                  <input
                    type="text"
                    name="national_id"
                    value={formData.national_id}
                    onChange={handleInputChange}
                    placeholder="رقم البطاقة"
                  />
                </div>
                <div className="form-group">
                  <label>رقم الهاتف</label>
                  <input
                    type="tel"
                    name="mobile_number"
                    value={formData.mobile_number}
                    onChange={handleInputChange}
                    placeholder="01xxxxxxxxx"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>القسم *</label>
                  <select
                    name="department_id"
                    value={formData.department_id}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">اختر القسم</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>المؤهل *</label>
                  <select
                    name="qualification_id"
                    value={formData.qualification_id}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">اختر المؤهل</option>
                    {qualifications.map(qual => (
                      <option key={qual.id} value={qual.id}>{qual.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>المسمى الوظيفي</label>
                  <input
                    type="text"
                    name="job_title"
                    value={formData.job_title}
                    onChange={handleInputChange}
                    placeholder="مثلاً: عامل إنتاج"
                  />
                </div>
                <div className="form-group">
                  <label>تاريخ التعيين</label>
                  <input
                    type="date"
                    name="hiring_date"
                    value={formData.hiring_date}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>الحالة</label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                  >
                    <option value="نشط">نشط</option>
                    <option value="غير نشط">غير نشط</option>
                  </select>
                </div>
              </div>

              <div className="form-group full-width">
                <label>ملاحظات</label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  placeholder="أي ملاحظات إضافية"
                  rows="3"
                ></textarea>
              </div>

              <div className="form-actions">
                <button type="submit" className="btn-save">💾 حفظ</button>
                <button type="button" className="btn-cancel" onClick={resetForm}>❌ إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* جدول الموظفين */}
      {loading ? (
        <div className="loading">جاري تحميل البيانات...</div>
      ) : (
        <div className="employees-table-container">
          <table className="employees-table">
            <thead>
              <tr>
                <th>معرف الموظف</th>
                <th>الاسم</th>
                <th>القسم</th>
                <th>المؤهل</th>
                <th>الرقم القومي</th>
                <th>الحالة</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {employees.length > 0 ? (
                employees.map(emp => (
                  <tr key={emp.id}>
                    <td>{emp.employee_id}</td>
                    <td>{emp.full_name}</td>
                    <td>{emp.department_name || '-'}</td>
                    <td>{emp.qualification_name || '-'}</td>
                    <td>{emp.national_id || '-'}</td>
                    <td>
                      <span className={`status-badge ${emp.status === 'نشط' ? 'active' : 'inactive'}`}>
                        {emp.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn-edit" onClick={() => handleEdit(emp)}>✏️</button>
                      <button className="btn-delete" onClick={() => handleDelete(emp.id)}>🗑️</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="7" className="no-data">لا توجد بيانات</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Employees;
