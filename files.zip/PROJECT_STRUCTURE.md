# Manufacturing ERP System - Complete Project Structure

## Project Overview
Enterprise Manufacturing ERP & Production Tracking Web Application for railway coach, heavy equipment, and industrial production facilities.

## Technology Stack
- **Frontend**: React 18 + TypeScript
- **Backend**: Firebase (Firestore, Auth, Storage, Realtime DB)
- **UI Framework**: Material-UI (MUI) v5
- **Charts**: Recharts & Apache ECharts
- **State Management**: Redux Toolkit
- **Real-time**: Firebase Realtime Database
- **Language**: Arabic (i18n-js)

## Directory Structure
```
manufacturing-erp/
├── public/
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Navbar.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Layout.tsx
│   │   │   └── ProtectedRoute.tsx
│   │   ├── auth/
│   │   │   ├── Login.tsx
│   │   │   └── PrivateRoute.tsx
│   │   ├── dashboard/
│   │   │   ├── ExecutiveDashboard.tsx
│   │   │   ├── ManagerDashboard.tsx
│   │   │   ├── KPICards.tsx
│   │   │   └── RealtimeCharts.tsx
│   │   ├── projects/
│   │   │   ├── ProjectsList.tsx
│   │   │   ├── ProjectForm.tsx
│   │   │   ├── ProjectDetails.tsx
│   │   │   └── VehicleTracking.tsx
│   │   ├── production/
│   │   │   ├── ProductionPlanning.tsx
│   │   │   ├── StageTracking.tsx
│   │   │   ├── WorkOrders.tsx
│   │   │   └── DailyTargets.tsx
│   │   ├── quality/
│   │   │   ├── QualityInspection.tsx
│   │   │   ├── InspectionForm.tsx
│   │   │   ├── NCRTracking.tsx
│   │   │   └── TestingModule.tsx
│   │   ├── warehouse/
│   │   │   ├── InventoryDashboard.tsx
│   │   │   ├── MaterialList.tsx
│   │   │   ├── ReorderAlerts.tsx
│   │   │   └── StockMovement.tsx
│   │   ├── procurement/
│   │   │   ├── PurchaseOrders.tsx
│   │   │   ├── PurchaseRequests.tsx
│   │   │   ├── SupplierManagement.tsx
│   │   │   └── SupplierPerformance.tsx
│   │   ├── workshop/
│   │   │   ├── StoppageManagement.tsx
│   │   │   ├── StoppageForm.tsx
│   │   │   └── StoppageAnalytics.tsx
│   │   ├── engineering/
│   │   │   ├── DrawingManagement.tsx
│   │   │   ├── DrawingApproval.tsx
│   │   │   ├── VersionControl.tsx
│   │   │   └── TechnicalDocs.tsx
│   │   ├── bottlenecks/
│   │   │   ├── BottleneckAnalysis.tsx
│   │   │   └── BottleneckDetails.tsx
│   │   ├── reporting/
│   │   │   ├── ReportGenerator.tsx
│   │   │   ├── DailyReport.tsx
│   │   │   ├── WeeklyReport.tsx
│   │   │   ├── MonthlyAnalytics.tsx
│   │   │   └── ExcelExporter.tsx
│   │   └── admin/
│   │       ├── AdminPanel.tsx
│   │       ├── UserManagement.tsx
│   │       ├── RoleManagement.tsx
│   │       ├── DepartmentSetup.tsx
│   │       ├── StageConfiguration.tsx
│   │       ├── NotificationSettings.tsx
│   │       └── SystemSettings.tsx
│   ├── services/
│   │   ├── firebase.ts
│   │   ├── authService.ts
│   │   ├── projectService.ts
│   │   ├── productionService.ts
│   │   ├── qualityService.ts
│   │   ├── warehouseService.ts
│   │   ├── procurementService.ts
│   │   ├── reportService.ts
│   │   └── notificationService.ts
│   ├── store/
│   │   ├── index.ts
│   │   ├── slices/
│   │   │   ├── authSlice.ts
│   │   │   ├── projectSlice.ts
│   │   │   ├── productionSlice.ts
│   │   │   ├── qualitySlice.ts
│   │   │   └── uiSlice.ts
│   │   └── hooks.ts
│   ├── types/
│   │   ├── index.ts
│   │   ├── project.ts
│   │   ├── production.ts
│   │   ├── quality.ts
│   │   ├── user.ts
│   │   └── common.ts
│   ├── utils/
│   │   ├── constants.ts
│   │   ├── helpers.ts
│   │   ├── validators.ts
│   │   ├── dateUtils.ts
│   │   └── exporters.ts
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useProject.ts
│   │   ├── useRealtime.ts
│   │   └── useNotification.ts
│   ├── i18n/
│   │   ├── ar.json
│   │   ├── en.json
│   │   └── i18n.ts
│   ├── styles/
│   │   ├── theme.ts
│   │   └── globals.css
│   ├── App.tsx
│   └── index.tsx
├── package.json
├── tsconfig.json
├── .env.example
├── .firebaserc
└── README.md
```

## Firebase Firestore Database Schema

### Collections:
1. **users** - User profiles and permissions
2. **projects** - Project information
3. **vehicles** - Individual vehicles/coaches tracking
4. **stages** - Production stages (configurable)
5. **departments** - Department information
6. **roles** - Role definitions with permissions
7. **production_schedules** - Daily/weekly targets
8. **work_orders** - Work order tracking
9. **warehouse_materials** - Raw materials inventory
10. **spare_parts** - Spare parts inventory
11. **purchase_orders** - Procurement orders
12. **quality_inspections** - Inspection records
13. **ncr_records** - Non-Conformance Reports
14. **test_results** - Testing module results
15. **workshop_stoppages** - Production stoppages
16. **engineering_drawings** - CAD & technical documents
17. **alerts** - Real-time alert system
18. **notifications** - User notifications
19. **reports** - Generated reports

## Key Features Implemented:
✅ Complete Firebase integration with Firestore
✅ Role-based access control (RBAC)
✅ Real-time data synchronization
✅ Multi-language support (Arabic/English)
✅ Responsive Material-UI design
✅ Redux state management
✅ Complete authentication system
✅ Production tracking with stages
✅ Quality inspection workflow
✅ Workshop stoppage management
✅ Inventory management
✅ Procurement system
✅ Real-time alerting
✅ Reporting & analytics
✅ Document management
✅ Excel/PDF export capabilities

## Setup Instructions
See README.md for detailed setup and deployment instructions.
