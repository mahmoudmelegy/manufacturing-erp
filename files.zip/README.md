# Manufacturing ERP System - Complete Setup & Deployment Guide

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Firebase Setup](#firebase-setup)
5. [Configuration](#configuration)
6. [Development](#development)
7. [Production Deployment](#production-deployment)
8. [Database Schema](#database-schema)
9. [API Documentation](#api-documentation)
10. [User Guide](#user-guide)
11. [Troubleshooting](#troubleshooting)

---

## Project Overview

### What is Manufacturing ERP?

A comprehensive enterprise resource planning system designed for:
- Railway coach manufacturing factories
- Heavy equipment manufacturing facilities
- Wagon manufacturing plants
- Industrial production facilities

### Key Features

✅ **Real-time Production Tracking** - Track each vehicle/coach through production stages
✅ **Role-Based Access Control** - 10 different user roles with customizable permissions
✅ **Quality Management** - Inspection, NCR tracking, and testing modules
✅ **Inventory Management** - Real-time warehouse and material tracking
✅ **Procurement System** - Purchase orders, requests, and supplier management
✅ **Executive Dashboard** - Real-time KPIs and analytics
✅ **Multi-language Support** - Arabic (default) and English
✅ **Real-time Alerts** - Instant notifications for critical events
✅ **Document Management** - Upload and manage technical documents
✅ **Reporting** - Daily, weekly, monthly, and annual reports with Excel/PDF export

---

## System Requirements

### Minimum Requirements
- **Node.js**: v16.0.0 or higher
- **npm**: v8.0.0 or higher
- **Browser**: Chrome, Firefox, Safari, or Edge (latest versions)
- **Storage**: 1GB free space

### Recommended Requirements
- **Node.js**: v18.0.0 or higher
- **RAM**: 4GB minimum
- **Internet**: 10 Mbps or higher

### Required Services
- Firebase Project (Firestore, Auth, Storage, Realtime DB)
- Internet connection for cloud sync

---

## Installation

### Step 1: Clone or Download Project

```bash
# Clone the repository
git clone https://github.com/yourorganization/manufacturing-erp.git
cd manufacturing-erp

# Or download and extract the zip file
unzip manufacturing-erp.zip
cd manufacturing-erp
```

### Step 2: Install Dependencies

```bash
# Install npm packages
npm install

# Verify installation
npm list
```

### Step 3: Create Environment File

```bash
# Copy the example environment file
cp .env.example .env.local

# Edit .env.local with your Firebase credentials
nano .env.local
```

---

## Firebase Setup

### 1. Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click "Create a new project"
3. Enter project name: "Manufacturing-ERP"
4. Accept the terms and create project

### 2. Enable Authentication

1. In Firebase Console → Authentication → Get Started
2. Enable these sign-in methods:
   - Email/Password
   - Google (recommended)

### 3. Create Firestore Database

1. In Firebase Console → Firestore Database → Create Database
2. Choose "Start in production mode"
3. Select region closest to your location
4. Add these security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow authenticated users to read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }

    // Projects
    match /projects/{projectId} {
      allow read: if request.auth != null;
      allow create, update, delete: if hasRole(['CHAIRMAN', 'FACTORY_MANAGER', 'ADMIN']);
    }

    // Vehicles
    match /projects/{projectId}/vehicles/{vehicleId} {
      allow read: if request.auth != null;
      allow write: if hasRole(['PROJECT_MANAGER', 'PRODUCTION_PLANNING']);
    }

    // Quality Inspections
    match /projects/{projectId}/inspections/{inspectionId} {
      allow read: if request.auth != null;
      allow create: if hasRole(['QUALITY']);
      allow update: if hasRole(['QUALITY', 'CHAIRMAN']);
    }

    // Helper function to check user role
    function hasRole(roles) {
      return request.auth != null && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in roles;
    }

    // Default: deny all other access
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

### 4. Setup Firebase Storage

1. In Firebase Console → Storage → Get Started
2. Keep default rules (authenticated users can upload)
3. Set storage to your nearest region

### 5. Create Realtime Database (Optional, for real-time updates)

1. In Firebase Console → Realtime Database → Create Database
2. Start in "Test Mode" (for development)
3. For production, update security rules

### 6: Get Firebase Configuration

1. In Firebase Console → Project Settings → General
2. Scroll to "Your apps" section
3. Click on the web app
4. Copy the firebase config object
5. Update your `.env.local` file with these values:

```
REACT_APP_FIREBASE_API_KEY=your_api_key
REACT_APP_FIREBASE_AUTH_DOMAIN=your_app.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=your-project-id
REACT_APP_FIREBASE_STORAGE_BUCKET=your-app.appspot.com
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
REACT_APP_FIREBASE_APP_ID=your_app_id
REACT_APP_FIREBASE_DATABASE_URL=https://your-project-id.firebaseio.com
```

---

## Configuration

### 1. Update Environment Variables

Edit `.env.local`:

```env
# Firebase Configuration
REACT_APP_FIREBASE_API_KEY=AIzaSyD...
REACT_APP_FIREBASE_AUTH_DOMAIN=manufacturing-erp.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=manufacturing-erp
REACT_APP_FIREBASE_STORAGE_BUCKET=manufacturing-erp.appspot.com
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=123456789
REACT_APP_FIREBASE_APP_ID=1:123456789:web:abc123...
REACT_APP_FIREBASE_DATABASE_URL=https://manufacturing-erp.firebaseio.com

# App Configuration
REACT_APP_API_BASE_URL=http://localhost:3000
REACT_APP_ENVIRONMENT=development
REACT_APP_LOG_LEVEL=debug

# Language Configuration
REACT_APP_DEFAULT_LANGUAGE=ar

# Feature Flags
REACT_APP_ENABLE_REAL_TIME_UPDATES=true
REACT_APP_ENABLE_NOTIFICATIONS=true
REACT_APP_ENABLE_ANALYTICS=true
```

### 2. Initialize Firestore Collections

Run this once to create initial admin user and system data:

```bash
npm run init-db
```

---

## Development

### Start Development Server

```bash
npm start
```

The application will open at `http://localhost:3000`

### Default Login Credentials (Development)

- **Email**: admin@manufacturing-erp.com
- **Password**: AdminPassword123!

### Development Commands

```bash
# Run tests
npm test

# Run linting
npm run lint

# Format code
npm run format

# Type check
npm run type-check

# Build for production
npm run build
```

---

## Production Deployment

### Option 1: Firebase Hosting (Recommended)

#### Install Firebase CLI

```bash
npm install -g firebase-tools
firebase login
```

#### Initialize Firebase Hosting

```bash
firebase init hosting
```

#### Build and Deploy

```bash
# Build the application
npm run build

# Deploy to Firebase Hosting
firebase deploy

# Or deploy specific targets
firebase deploy --only hosting:manufacturing-erp
```

### Option 2: AWS S3 + CloudFront

```bash
# Build the application
npm run build

# Configure AWS credentials
aws configure

# Deploy to S3
aws s3 sync build/ s3://your-bucket-name/

# Invalidate CloudFront cache
aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths "/*"
```

### Option 3: Docker Deployment

#### Create Dockerfile

```dockerfile
# Build stage
FROM node:18-alpine as builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Production stage
FROM node:18-alpine
RUN npm install -g serve
WORKDIR /app
COPY --from=builder /app/build ./build
EXPOSE 3000
CMD ["serve", "-s", "build", "-l", "3000"]
```

#### Build and Run Docker Image

```bash
# Build image
docker build -t manufacturing-erp:latest .

# Run container
docker run -p 3000:3000 -e REACT_APP_FIREBASE_API_KEY=... manufacturing-erp:latest

# Push to registry
docker push your-registry/manufacturing-erp:latest
```

### Option 4: Traditional Server (Node.js)

```bash
# Build application
npm run build

# Install serve package globally
npm install -g serve

# Run production server
serve -s build -l 3000

# For PM2 (recommended for production)
npm install -g pm2
pm2 start "serve -s build -l 3000" --name "manufacturing-erp"
pm2 save
pm2 startup
```

### Post-Deployment Configuration

1. **Update Firebase Hosting Security Rules**
   - Update CORS settings if needed
   - Configure custom domains

2. **Set Up Email Notifications**
   - Configure SendGrid or Firebase Cloud Messaging
   - Set up email templates

3. **Enable Analytics**
   - Set up Google Analytics
   - Configure custom events

4. **Configure Backups**
   - Enable Firestore backups
   - Set up automated daily backups

5. **Set Up Monitoring**
   - Configure Firebase Performance Monitoring
   - Set up error logging (Sentry, etc.)

---

## Database Schema

### Collections Overview

#### 1. users
```
users/
├── {userId}
│   ├── email: string
│   ├── name: string
│   ├── role: UserRole
│   ├── department: string
│   ├── permissions: Permission[]
│   ├── isActive: boolean
│   ├── createdAt: timestamp
│   └── lastLogin: timestamp
```

#### 2. projects
```
projects/
├── {projectId}
│   ├── name: string
│   ├── clientName: string
│   ├── contractNumber: string
│   ├── contractValue: number
│   ├── startDate: timestamp
│   ├── deliveryDate: timestamp
│   ├── status: ProjectStatus
│   ├── progress: number (0-100)
│   ├── stages: string[] (stage IDs)
│   ├── vehicles/
│   │   └── {vehicleId}
│   │       ├── vehicleNumber: string
│   │       ├── status: VehicleStatus
│   │       ├── stageProgress: StageProgress[]
│   │       ├── qualityStatus: string
│   │       └── spareParts: SparePart[]
│   ├── inspections/
│   │   └── {inspectionId}
│   ├── ncr_records/
│   │   └── {ncrId}
│   └── test_results/
│       └── {testId}
```

#### 3. warehouse_materials
```
warehouse_materials/
├── {materialId}
│   ├── code: string
│   ├── name: string
│   ├── category: string
│   ├── unit: string
│   ├── availableQuantity: number
│   ├── reservedQuantity: number
│   ├── reorderLevel: number
│   ├── unitPrice: number
│   └── supplier: string
```

#### 4. purchase_orders
```
purchase_orders/
├── {poId}
│   ├── poNumber: string
│   ├── supplier: string
│   ├── items: PurchaseOrderItem[]
│   ├── totalAmount: number
│   ├── status: POStatus
│   ├── deliveryDate: timestamp
│   └── createdAt: timestamp
```

#### 5. quality_inspections
```
projects/{projectId}/inspections/
├── {inspectionId}
│   ├── vehicleId: string
│   ├── inspectionType: string
│   ├── status: 'APPROVED' | 'REJECTED' | 'PENDING'
│   ├── findings: QualityFinding[]
│   ├── photos: string[] (storage URLs)
│   └── inspectionDate: timestamp
```

#### 6. workshop_stoppages
```
workshop_stoppages/
├── {stoppageId}
│   ├── projectId: string
│   ├── department: string
│   ├── reason: StoppageReason
│   ├── duration: number (minutes)
│   ├── status: 'ACTIVE' | 'RESOLVED'
│   └── startTime: timestamp
```

---

## API Documentation

### Authentication Service

```typescript
// Sign up new user
authService.register(email, password, name, role, department)

// Sign in
authService.signIn(email, password)

// Sign out
authService.signOut()

// Get current user profile
authService.getCurrentUserProfile(userId)

// Check permissions
authService.hasPermission(user, resource, action)
```

### Project Service

```typescript
// Create project
projectService.createProject(projectData)

// Get all projects
projectService.getAllProjects(status?)

// Create vehicle
projectService.createVehicle(projectId, vehicleData)

// Get vehicle
projectService.getVehicle(projectId, vehicleId)

// Update vehicle stage progress
projectService.updateVehicleStageProgress(projectId, vehicleId, stageProgress)

// Subscribe to real-time updates
projectService.subscribeToProject(projectId, callback)
projectService.subscribeToVehicle(projectId, vehicleId, callback)
```

### Quality Service

```typescript
// Create inspection
qualityService.createInspection(projectId, inspectionData)

// Get vehicle inspections
qualityService.getVehicleInspections(projectId, vehicleId)

// Approve inspection
qualityService.approveInspection(projectId, inspectionId, approvedBy)

// Create NCR
qualityService.createNCR(projectId, ncrData)

// Create test result
qualityService.createTestResult(projectId, testData)

// Get quality metrics
qualityService.getQualityMetrics(projectId)
```

### Warehouse Service

```typescript
// Create material
warehouseService.createMaterial(materialData)

// Get materials
warehouseService.getMaterials(category?)

// Record material movement
warehouseService.recordMaterialMovement(movement)

// Reserve material
warehouseService.reserveMaterial(materialId, quantity, reference)

// Get low stock items
warehouseService.getLowStockMaterials()

// Get inventory summary
warehouseService.getInventorySummary()
```

### Procurement Service

```typescript
// Create purchase request
procurementService.createPurchaseRequest(requestData)

// Create purchase order
procurementService.createPurchaseOrder(orderData)

// Approve purchase request
procurementService.approvePurchaseRequest(requestId, approvedBy)

// Create supplier
procurementService.createSupplier(supplierData)

// Get procurement metrics
procurementService.getProcurementMetrics()
```

### Notification Service

```typescript
// Create alert
notificationService.createAlert(alertData)

// Create user notification
notificationService.createNotification(userId, notificationData)

// Get user notifications
notificationService.getUserNotifications(userId, unreadOnly?)

// Mark as read
notificationService.markNotificationAsRead(userId, notificationId)

// Get critical alerts
notificationService.getCriticalAlerts()

// Subscribe to real-time notifications
notificationService.subscribeToUserNotifications(userId, callback)
```

---

## User Guide

### 1. Login & Authentication

1. Navigate to the login page
2. Enter your email and password
3. Click "تسجيل الدخول" (Sign In)
4. You'll be redirected to your dashboard based on your role

### 2. Project Management

#### Creating a New Project

1. Go to "المشاريع" (Projects)
2. Click "إنشاء مشروع جديد" (Create New Project)
3. Fill in:
   - Project Name
   - Client Name
   - Contract Number
   - Contract Value
   - Start Date
   - Delivery Date
   - Project Manager
4. Click "إنشاء" (Create)

#### Adding Vehicles to Project

1. Open the project
2. Go to "المركبات" (Vehicles)
3. Click "إضافة مركبة" (Add Vehicle)
4. Enter vehicle details
5. Click "إضافة" (Add)

### 3. Production Tracking

1. Go to "الإنتاج" (Production)
2. Select project and vehicle
3. View current stage progress
4. Update stage progress as work completes
5. Upload photos and documents

### 4. Quality Management

#### Creating an Inspection

1. Go to "الجودة" (Quality)
2. Click "فحص جديد" (New Inspection)
3. Select vehicle and stage
4. Record findings
5. Upload inspection photos
6. Click "حفظ" (Save)

#### Approving/Rejecting

1. Click on inspection record
2. Review findings
3. Click "موافقة" (Approve) or "رفض" (Reject)
4. Add comments if rejecting

### 5. Warehouse Management

1. Go to "المستودع" (Warehouse)
2. View all materials and inventory levels
3. Create purchase requests for low-stock items
4. Record material movements

### 6. Procurement

1. Go to "المشتريات" (Procurement)
2. Create purchase requests
3. Approve requests
4. Generate purchase orders
5. Track supplier performance

### 7. Reporting

1. Go to "التقارير" (Reports)
2. Select report type (Daily, Weekly, Monthly, etc.)
3. Choose date range
4. Click "إنشاء تقرير" (Generate Report)
5. Export to Excel or PDF

---

## Troubleshooting

### Common Issues and Solutions

#### Issue: Firebase Authentication Not Working

**Solution:**
```bash
# Clear browser cache and cookies
# Check Firebase credentials in .env.local
# Verify email/password authentication is enabled in Firebase console
# Check Firebase project region settings
```

#### Issue: Real-time Updates Not Showing

**Solution:**
```bash
# Check Firestore security rules
# Verify REACT_APP_ENABLE_REAL_TIME_UPDATES=true in .env
# Check browser console for errors
# Verify user has read permissions in Firestore
```

#### Issue: Images/Files Not Uploading

**Solution:**
```bash
# Check Firebase Storage bucket exists
# Verify storage security rules allow authenticated uploads
# Check file size limits
# Verify CORS settings in Firebase Storage
```

#### Issue: Build Errors

**Solution:**
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear React cache
rm -rf .cache
npm run build

# Check Node version
node --version  # Should be v16 or higher
```

#### Issue: Slow Performance

**Solution:**
```bash
# Optimize image sizes before upload
# Use React.lazy() for code splitting
# Enable Firestore indexes for common queries
# Use Firebase CDN for static assets
# Monitor bundle size: npm run analyze
```

### Getting Help

1. **Documentation**: Check the PROJECT_STRUCTURE.md and README files
2. **Firebase Support**: https://firebase.google.com/support
3. **React Documentation**: https://react.dev
4. **GitHub Issues**: Create an issue with detailed information

---

## Security Checklist

- [ ] Change default admin password
- [ ] Enable two-factor authentication
- [ ] Review Firestore security rules
- [ ] Configure Firebase Storage security rules
- [ ] Set up rate limiting
- [ ] Enable HTTPS/SSL
- [ ] Set up automated backups
- [ ] Configure activity logging
- [ ] Review user access permissions
- [ ] Enable audit logs

---

## Performance Optimization

### Recommended Optimizations

1. **Enable Firestore Indexes**
   - Go to Firestore → Indexes
   - Create indexes for common queries

2. **Use Firebase Caching**
   - Enable offline persistence
   - Use appropriate cache strategies

3. **Optimize Bundle Size**
   - Use dynamic imports
   - Tree-shake unused code
   - Lazy load components

4. **Database Optimization**
   - Batch writes for multiple updates
   - Use transactions for data consistency
   - Archive old data regularly

---

## Support & Maintenance

### Regular Maintenance Tasks

- **Weekly**: Check system logs and error reports
- **Monthly**: Review user access and permissions
- **Quarterly**: Analyze performance metrics
- **Annually**: Conduct security audit

### Updates & Upgrades

```bash
# Check for npm package updates
npm outdated

# Update packages safely
npm update

# Update with breaking changes
npm install <package>@latest
```

---

## License

This project is proprietary software. All rights reserved.

**Copyright © 2024 Manufacturing ERP Systems**

For licensing inquiries, contact: license@manufacturing-erp.com

---

## Contact & Support

- **Email**: support@manufacturing-erp.com
- **Phone**: +966-XX-XXXX-XXXX
- **Website**: https://www.manufacturing-erp.com
- **Documentation**: https://docs.manufacturing-erp.com

---

**Version**: 1.0.0
**Last Updated**: 2024
**Next Review**: 2025
