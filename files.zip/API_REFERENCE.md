# Manufacturing ERP - Complete API Reference

## Services Architecture

All business logic is encapsulated in services following the Service Layer pattern. Each service handles a specific domain.

---

## 1. Authentication Service (`authService`)

### Methods

#### `register(email, password, name, role, department): Promise<User>`
Create a new user account.

```typescript
await authService.register(
  'john@company.com',
  'SecurePass123!',
  'John Smith',
  'PRODUCTION_PLANNING',
  'Production'
);
```

**Parameters:**
- `email` (string): User email
- `password` (string): Password (min 8 chars)
- `name` (string): Full name
- `role` (UserRole): One of 10 roles
- `department` (string): Department name

**Returns:** `User` object

---

#### `signIn(email, password): Promise<FirebaseUser>`
Authenticate user with email/password.

```typescript
const user = await authService.signIn('john@company.com', 'SecurePass123!');
```

**Parameters:**
- `email` (string): User email
- `password` (string): User password

**Returns:** Firebase User object

**Throws:** Authentication error

---

#### `signOut(): Promise<void>`
Sign out current user.

```typescript
await authService.signOut();
```

---

#### `getCurrentUserProfile(uid): Promise<User | null>`
Fetch user profile from Firestore.

```typescript
const profile = await authService.getCurrentUserProfile(userId);
```

**Parameters:**
- `uid` (string): Firebase user ID

**Returns:** User profile object or null

---

#### `updateUserProfile(userId, updates): Promise<void>`
Update user profile information.

```typescript
await authService.updateUserProfile(userId, {
  name: 'New Name',
  phone: '+966551234567',
  department: 'Engineering'
});
```

**Parameters:**
- `userId` (string): User ID
- `updates` (Partial<User>): Fields to update

---

#### `changePassword(currentPassword, newPassword): Promise<void>`
Change user password with authentication.

```typescript
await authService.changePassword(
  'CurrentPassword123!',
  'NewPassword456!'
);
```

**Parameters:**
- `currentPassword` (string): Current password
- `newPassword` (string): New password (min 8 chars)

---

#### `getUsers(role?, department?): Promise<User[]>`
Get all users with optional filtering.

```typescript
const qualityTeam = await authService.getUsers('QUALITY', 'Quality Department');
```

**Parameters:**
- `role` (string, optional): Filter by role
- `department` (string, optional): Filter by department

**Returns:** Array of User objects

---

#### `hasPermission(user, resource, action): boolean`
Check if user has specific permission.

```typescript
if (authService.hasPermission(user, 'projects', 'create')) {
  // Allow action
}
```

**Parameters:**
- `user` (User): User object
- `resource` (string): Resource name (e.g., 'projects')
- `action` (string): Action ('read', 'create', 'update', 'delete', 'approve')

**Returns:** boolean

---

#### `onAuthStateChanged(callback): Unsubscribe`
Listen to auth state changes.

```typescript
const unsubscribe = authService.onAuthStateChanged((user) => {
  if (user) {
    console.log('User logged in:', user.uid);
  } else {
    console.log('User logged out');
  }
});

// Don't forget to unsubscribe
return unsubscribe;
```

**Parameters:**
- `callback` (function): Callback fired on auth state change

**Returns:** Unsubscribe function

---

## 2. Project Service (`projectService`)

### Methods

#### `createProject(projectData): Promise<Project>`
Create new manufacturing project.

```typescript
const project = await projectService.createProject({
  name: 'Metro Coaches 2024',
  clientName: 'City Transport Authority',
  contractNumber: 'CT-2024-001',
  contractValue: 5000000,
  currency: 'SAR',
  startDate: new Date('2024-01-01'),
  deliveryDate: new Date('2024-12-31'),
  projectManager: 'managerId',
  status: 'PLANNING',
  priority: 'HIGH',
  notes: 'High-priority project',
  totalVehicles: 100,
  completedVehicles: 0,
  stages: [],
  departments: [],
  progress: 0
});
```

---

#### `getProject(projectId): Promise<Project | null>`
Fetch single project by ID.

```typescript
const project = await projectService.getProject('proj-123');
```

---

#### `getAllProjects(status?): Promise<Project[]>`
Get all projects with optional status filter.

```typescript
const activeProjects = await projectService.getAllProjects('ACTIVE');
```

---

#### `updateProject(projectId, updates): Promise<void>`
Update project information.

```typescript
await projectService.updateProject('proj-123', {
  status: 'IN_PRODUCTION',
  progress: 25
});
```

---

#### `deleteProject(projectId): Promise<void>`
Delete a project.

```typescript
await projectService.deleteProject('proj-123');
```

---

#### `createStage(projectId, stageData): Promise<Stage>`
Create production stage for project.

```typescript
const stage = await projectService.createStage('proj-123', {
  projectId: 'proj-123',
  name: 'Chassis Fabrication',
  description: 'Fabricate vehicle chassis',
  sequence: 3,
  estimatedDays: 15,
  department: 'Manufacturing',
  predecessors: ['stage-1', 'stage-2'],
  successors: []
});
```

---

#### `getProjectStages(projectId): Promise<Stage[]>`
Get all stages for a project.

```typescript
const stages = await projectService.getProjectStages('proj-123');
```

---

#### `createVehicle(projectId, vehicleData): Promise<Vehicle>`
Create vehicle for project.

```typescript
const vehicle = await projectService.createVehicle('proj-123', {
  projectId: 'proj-123',
  vehicleNumber: 'MC-001',
  type: 'Coach',
  status: 'PLANNING',
  description: 'Metro Coach Unit 001',
  stageProgress: [],
  spareParts: [],
  qualityStatus: 'PENDING_INSPECTION',
  currentStage: 'stage-1',
  currentStageDueDate: new Date(),
  estimatedCompletionDate: new Date(),
  photos: [],
  documents: []
});
```

---

#### `getProjectVehicles(projectId): Promise<Vehicle[]>`
Get all vehicles in project.

```typescript
const vehicles = await projectService.getProjectVehicles('proj-123');
```

---

#### `getVehicle(projectId, vehicleId): Promise<Vehicle | null>`
Get single vehicle details.

```typescript
const vehicle = await projectService.getVehicle('proj-123', 'veh-123');
```

---

#### `updateVehicle(projectId, vehicleId, updates): Promise<void>`
Update vehicle information.

```typescript
await projectService.updateVehicle('proj-123', 'veh-123', {
  status: 'IN_PRODUCTION',
  progress: 50
});
```

---

#### `updateVehicleStageProgress(projectId, vehicleId, stageProgress): Promise<void>`
Update vehicle's stage progress.

```typescript
await projectService.updateVehicleStageProgress(
  'proj-123',
  'veh-123',
  {
    stageId: 'stage-1',
    stageName: 'Engineering Design',
    status: 'COMPLETED',
    startDate: new Date('2024-01-01'),
    completionDate: new Date('2024-01-15'),
    dueDate: new Date('2024-01-15'),
    progress: 100,
    assignedTo: 'user-123',
    notes: 'Design completed as per specs'
  }
);
```

---

#### `subscribeToProject(projectId, callback): Unsubscribe`
Listen to real-time project updates.

```typescript
const unsubscribe = projectService.subscribeToProject('proj-123', (project) => {
  console.log('Project updated:', project);
});
```

---

#### `subscribeToVehicle(projectId, vehicleId, callback): Unsubscribe`
Listen to real-time vehicle updates.

```typescript
const unsubscribe = projectService.subscribeToVehicle(
  'proj-123',
  'veh-123',
  (vehicle) => {
    console.log('Vehicle updated:', vehicle);
  }
);
```

---

## 3. Quality Service (`qualityService`)

### Methods

#### `createInspection(projectId, inspectionData): Promise<QualityInspection>`
Create quality inspection record.

```typescript
const inspection = await qualityService.createInspection('proj-123', {
  projectId: 'proj-123',
  vehicleId: 'veh-123',
  stageId: 'stage-3',
  inspectionType: 'STAGE',
  inspectedBy: 'user-456',
  inspectionDate: new Date(),
  status: 'PENDING',
  findings: [
    {
      id: 'finding-1',
      item: 'Welding Quality',
      standard: 'ISO 5817',
      result: 'PASS',
      comment: 'Excellent work'
    }
  ],
  photos: ['photo-url-1', 'photo-url-2'],
  report: 'Inspection report text'
});
```

---

#### `getVehicleInspections(projectId, vehicleId): Promise<QualityInspection[]>`
Get all inspections for a vehicle.

```typescript
const inspections = await qualityService.getVehicleInspections('proj-123', 'veh-123');
```

---

#### `approveInspection(projectId, inspectionId, approvedBy): Promise<void>`
Approve inspection and allow next stage.

```typescript
await qualityService.approveInspection('proj-123', 'insp-123', 'user-456');
```

---

#### `rejectInspection(projectId, inspectionId, reason): Promise<void>`
Reject inspection and block next stage.

```typescript
await qualityService.rejectInspection(
  'proj-123',
  'insp-123',
  'Welding issues found, requires rework'
);
```

---

#### `createNCR(projectId, ncrData): Promise<NCRRecord>`
Create Non-Conformance Report.

```typescript
const ncr = await qualityService.createNCR('proj-123', {
  projectId: 'proj-123',
  vehicleId: 'veh-123',
  ncrNumber: 'NCR-2024-001',
  description: 'Paint defects on body panel',
  severity: 'HIGH',
  reportedBy: 'user-456',
  reportedDate: new Date(),
  rootCause: 'Spray gun malfunction',
  correctiveAction: 'Replace spray gun and repaint',
  assignedTo: 'user-789',
  dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
  status: 'OPEN'
});
```

---

#### `getVehicleNCRs(projectId, vehicleId): Promise<NCRRecord[]>`
Get all NCRs for a vehicle.

```typescript
const ncrs = await qualityService.getVehicleNCRs('proj-123', 'veh-123');
```

---

#### `updateNCRStatus(projectId, ncrId, status, completedDate?): Promise<void>`
Update NCR status.

```typescript
await qualityService.updateNCRStatus(
  'proj-123',
  'ncr-123',
  'COMPLETED',
  new Date()
);
```

---

#### `createTestResult(projectId, testData): Promise<TestResult>`
Record test results.

```typescript
const test = await qualityService.createTestResult('proj-123', {
  vehicleId: 'veh-123',
  testType: 'BRAKE',
  testDate: new Date(),
  testedBy: 'user-456',
  result: 'PASS',
  observations: 'All brake systems functioning properly',
  defects: [],
  certificationNumber: 'TEST-2024-001'
});
```

---

#### `getVehicleTestResults(projectId, vehicleId): Promise<TestResult[]>`
Get all test results for a vehicle.

```typescript
const tests = await qualityService.getVehicleTestResults('proj-123', 'veh-123');
```

---

#### `getQualityMetrics(projectId): Promise<Object>`
Get quality metrics and statistics.

```typescript
const metrics = await qualityService.getQualityMetrics('proj-123');
// Returns: {
//   totalInspections: 50,
//   approvedInspections: 45,
//   rejectedInspections: 5,
//   approvalRate: 90,
//   totalTests: 40,
//   passedTests: 39,
//   failedTests: 1,
//   passRate: 97.5,
//   totalNCRs: 8,
//   openNCRs: 2,
//   criticalNCRs: 0
// }
```

---

#### `subscribeToInspection(projectId, inspectionId, callback): Unsubscribe`
Listen to inspection updates.

```typescript
const unsubscribe = qualityService.subscribeToInspection(
  'proj-123',
  'insp-123',
  (inspection) => {
    console.log('Inspection updated:', inspection);
  }
);
```

---

## 4. Warehouse Service (`warehouseService`)

### Methods

#### `createMaterial(materialData): Promise<Material>`
Add new material to inventory.

```typescript
const material = await warehouseService.createMaterial({
  code: 'MAT-001',
  name: 'Steel Plate 5mm',
  description: 'Carbon steel plate',
  category: 'Raw Materials',
  unit: 'kg',
  availableQuantity: 1000,
  reservedQuantity: 0,
  reorderLevel: 200,
  reorderQuantity: 500,
  unitPrice: 50,
  supplier: 'supp-123',
  location: 'A1-B2-C3'
});
```

---

#### `getMaterials(category?): Promise<Material[]>`
Get all materials with optional category filter.

```typescript
const steelMaterials = await warehouseService.getMaterials('Raw Materials');
```

---

#### `getMaterial(materialId): Promise<Material | null>`
Get single material details.

```typescript
const material = await warehouseService.getMaterial('mat-123');
```

---

#### `updateMaterial(materialId, updates): Promise<void>`
Update material information.

```typescript
await warehouseService.updateMaterial('mat-123', {
  unitPrice: 55,
  reorderLevel: 250
});
```

---

#### `recordMaterialMovement(movement): Promise<MaterialMovement>`
Record material in/out/adjustment.

```typescript
const movement = await warehouseService.recordMaterialMovement({
  materialId: 'mat-123',
  type: 'OUT',
  quantity: 100,
  reference: 'WO-2024-001',
  notes: 'Used in production',
  createdBy: 'user-456'
});
```

---

#### `reserveMaterial(materialId, quantity, reference): Promise<void>`
Reserve material for work order.

```typescript
await warehouseService.reserveMaterial(
  'mat-123',
  100,
  'WO-2024-001'
);
```

---

#### `getLowStockMaterials(): Promise<Material[]>`
Get all materials below reorder level.

```typescript
const lowStock = await warehouseService.getLowStockMaterials();
```

---

#### `getMaterialMovements(materialId, limit?): Promise<MaterialMovement[]>`
Get material movement history.

```typescript
const history = await warehouseService.getMaterialMovements('mat-123', 50);
```

---

#### `getInventorySummary(): Promise<Object>`
Get inventory overview and statistics.

```typescript
const summary = await warehouseService.getInventorySummary();
// Returns: {
//   totalItems: 150,
//   totalValue: 75000,
//   lowStockItems: 12,
//   categories: 8,
//   totalQuantity: 5000,
//   categoryBreakdown: [...]
// }
```

---

#### `subscribeToMaterial(materialId, callback): Unsubscribe`
Listen to material updates.

```typescript
const unsubscribe = warehouseService.subscribeToMaterial('mat-123', (material) => {
  console.log('Material updated:', material);
});
```

---

## 5. Procurement Service (`procurementService`)

### Methods

#### `createPurchaseRequest(requestData): Promise<PurchaseRequest>`
Create purchase request.

```typescript
const pr = await procurementService.createPurchaseRequest({
  projectId: 'proj-123',
  description: 'Steel materials for metro coach',
  materials: [
    { materialId: 'mat-123', quantity: 500, estimatedUnitPrice: 50 },
    { materialId: 'mat-456', quantity: 250, estimatedUnitPrice: 75 }
  ],
  requiredBy: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
  requestedBy: 'user-123',
  status: 'DRAFT'
});
```

---

#### `getPurchaseRequests(status?): Promise<PurchaseRequest[]>`
Get all purchase requests.

```typescript
const pending = await procurementService.getPurchaseRequests('SUBMITTED');
```

---

#### `getPurchaseRequest(requestId): Promise<PurchaseRequest | null>`
Get single purchase request.

```typescript
const pr = await procurementService.getPurchaseRequest('pr-123');
```

---

#### `approvePurchaseRequest(requestId, approvedBy): Promise<void>`
Approve purchase request.

```typescript
await procurementService.approvePurchaseRequest('pr-123', 'user-456');
```

---

#### `createPurchaseOrder(orderData): Promise<PurchaseOrder>`
Create purchase order from request.

```typescript
const po = await procurementService.createPurchaseOrder({
  poNumber: 'PO-2024-001',
  supplier: 'supp-123',
  purchaseRequestId: 'pr-123',
  items: [
    { materialId: 'mat-123', quantity: 500, unitPrice: 50, deliveredQuantity: 0 },
    { materialId: 'mat-456', quantity: 250, unitPrice: 75, deliveredQuantity: 0 }
  ],
  totalAmount: 43750,
  currency: 'SAR',
  deliveryDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
  paymentTerms: 'Net 30',
  status: 'DRAFT',
  createdBy: 'user-456'
});
```

---

#### `getPurchaseOrders(status?): Promise<PurchaseOrder[]>`
Get all purchase orders.

```typescript
const pending = await procurementService.getPurchaseOrders('SENT');
```

---

#### `updatePurchaseOrderStatus(orderId, status): Promise<void>`
Update PO status.

```typescript
await procurementService.updatePurchaseOrderStatus('po-123', 'CONFIRMED');
```

---

#### `updateDeliveredQuantity(orderId, itemIndex, deliveredQuantity): Promise<void>`
Update delivered quantity for PO item.

```typescript
await procurementService.updateDeliveredQuantity('po-123', 0, 500);
```

---

#### `createSupplier(supplierData): Promise<Supplier>`
Add new supplier.

```typescript
const supplier = await procurementService.createSupplier({
  name: 'Steel Supplies Inc',
  email: 'info@steelsupplies.com',
  phone: '+966551234567',
  address: '123 Industrial Road, Riyadh',
  materials: ['mat-123', 'mat-456'],
  rating: 4.5,
  onTimeDeliveryRate: 95,
  qualityRating: 4.8,
  leadTime: 7
});
```

---

#### `getSuppliers(): Promise<Supplier[]>`
Get all suppliers.

```typescript
const suppliers = await procurementService.getSuppliers();
```

---

#### `getSupplier(supplierId): Promise<Supplier | null>`
Get single supplier.

```typescript
const supplier = await procurementService.getSupplier('supp-123');
```

---

#### `updateSupplier(supplierId, updates): Promise<void>`
Update supplier information.

```typescript
await procurementService.updateSupplier('supp-123', {
  phone: '+966551111111',
  leadTime: 5
});
```

---

#### `updateSupplierRating(supplierId, rating, onTimeDeliveryRate, qualityRating): Promise<void>`
Update supplier performance rating.

```typescript
await procurementService.updateSupplierRating(
  'supp-123',
  4.6,
  96,
  4.9
);
```

---

#### `getPendingDeliveries(): Promise<PurchaseOrder[]>`
Get all pending purchase orders.

```typescript
const pending = await procurementService.getPendingDeliveries();
```

---

#### `getProcurementMetrics(): Promise<Object>`
Get procurement statistics.

```typescript
const metrics = await procurementService.getProcurementMetrics();
// Returns: {
//   totalRequests: 25,
//   approvedRequests: 20,
//   pendingRequests: 5,
//   totalOrders: 20,
//   deliveredOrders: 15,
//   pendingOrders: 3,
//   partialOrders: 2,
//   totalOrderValue: 500000
// }
```

---

## 6. Notification Service (`notificationService`)

### Methods

#### `createAlert(alertData): Promise<Alert>`
Create system alert.

```typescript
const alert = await notificationService.createAlert({
  type: 'MATERIAL_SHORTAGE',
  severity: 'HIGH',
  message: 'Steel plate stock below reorder level',
  projectId: 'proj-123'
});
```

---

#### `createNotification(userId, notificationData): Promise<Notification>`
Create user notification.

```typescript
const notif = await notificationService.createNotification('user-123', {
  type: 'QUALITY_REJECTION',
  title: 'Vehicle Rejected',
  message: 'Vehicle MC-001 requires rework',
  relatedId: 'veh-123'
});
```

---

#### `getUserNotifications(userId, unreadOnly?): Promise<Notification[]>`
Get user notifications.

```typescript
const notifications = await notificationService.getUserNotifications('user-123', true);
```

---

#### `markNotificationAsRead(userId, notificationId): Promise<void>`
Mark single notification as read.

```typescript
await notificationService.markNotificationAsRead('user-123', 'notif-123');
```

---

#### `markAllNotificationsAsRead(userId): Promise<void>`
Mark all notifications as read.

```typescript
await notificationService.markAllNotificationsAsRead('user-123');
```

---

#### `getRecentAlerts(count?): Promise<Alert[]>`
Get recent system alerts.

```typescript
const alerts = await notificationService.getRecentAlerts(10);
```

---

#### `getCriticalAlerts(): Promise<Alert[]>`
Get unread critical alerts.

```typescript
const critical = await notificationService.getCriticalAlerts();
```

---

#### `subscribeToUserNotifications(userId, callback): Unsubscribe`
Listen to user notifications.

```typescript
const unsubscribe = notificationService.subscribeToUserNotifications(
  'user-123',
  (notifications) => {
    console.log('New notifications:', notifications);
  }
);
```

---

## Error Handling

All services throw errors that can be caught:

```typescript
try {
  const project = await projectService.getProject('invalid-id');
} catch (error: any) {
  console.error(error.message);
  // Handle error appropriately
}
```

---

## Real-Time Subscriptions

All subscription methods return unsubscribe functions:

```typescript
const unsubscribe = projectService.subscribeToProject('proj-123', (project) => {
  // Handle updates
});

// Don't forget to unsubscribe when component unmounts
useEffect(() => {
  return unsubscribe;
}, []);
```

---

**Last Updated**: 2024
**API Version**: 1.0.0
